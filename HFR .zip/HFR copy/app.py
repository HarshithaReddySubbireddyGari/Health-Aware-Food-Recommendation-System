
from flask import Flask, request, jsonify, send_file, send_from_directory
from flask_cors import CORS
import pandas as pd
import json
import tempfile
import os
import traceback
from collections import defaultdict

try:
    from backend.scraper.scraper import extract_product_info, extract_product_info_enhanced
    from backend.ocr_processor.image_processor import process_product
    from backend.rules_engine.health_rules import HealthRulesEngine
    from backend.rules_engine.scoring import ProductScorer
    from backend.nlp_processor.tagging import NLPTagger
    print("✅ All backend modules imported successfully")
except ImportError as e:
    print(f"❌ Import error: {e}")
    traceback.print_exc()
    class HealthRulesEngine:
        def get_available_conditions(self): return {}
        def get_available_restrictions(self): return {}
    
    class ProductScorer:
        def analyze_product_health(self, product, profile): 
            return {
                'overall_recommendation': 'Analysis Error',
                'detailed_explanations': ['Import error - using fallback'],
                'medical_warnings': [],
                'positive_factors': [],
                'sources': [],
                'preference_warnings': [],
                'allergen_warnings': [],
                'overall_score': 0
            }
    
    class NLPTagger:
        def generate_tags(self, product): return []

app = Flask(__name__, static_folder='frontend', static_url_path='')
CORS(app)

try:
    rules_engine = HealthRulesEngine()
    scorer = ProductScorer()
    nlp_tagger = NLPTagger()
    print("✅ All engines initialized successfully")
except Exception as e:
    print(f"❌ Engine initialization error: {e}")
    traceback.print_exc()

@app.route('/')
def serve_index():
    return send_from_directory('frontend', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('frontend', path)

@app.route('/upload')
def serve_upload():
    return send_from_directory('frontend', 'upload.html')

@app.route('/health-profile')
def serve_health_profile():
    return send_from_directory('frontend', 'health-profile.html')

@app.route('/recommendations')
def serve_recommendations():
    return send_from_directory('frontend', 'recommendations.html')

@app.route('/css/<path:path>')
def serve_css(path):
    return send_from_directory('frontend/css', path)

@app.route('/js/<path:path>')
def serve_js(path):
    return send_from_directory('frontend/js', path)

@app.route('/api/process-urls', methods=['POST'])
def process_urls():
    """Process CSV file with product URLs"""
    try:
        print("📥 Processing URLs request received")
        
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        df = pd.read_csv(file)
        if 'url' not in df.columns:
            return jsonify({'error': 'CSV must contain "url" column'}), 400
        
        print(f"📊 Processing {len(df)} URLs")
        
        results = []
        for idx, url in enumerate(df['url']):
            try:
                print(f"🔍 Scraping URL {idx+1}: {url}")
                product_data = extract_product_info_enhanced(url)
                results.append(product_data)
                
                if 'Error' not in product_data.get('product_name', ''):
                    print(f"✅ Successfully scraped: {product_data.get('product_name', 'Unknown')}")
                    print(f"   - Ingredients: {'Yes' if product_data.get('ingredients') else 'No'}")
                    print(f"   - Allergens: {'Yes' if product_data.get('allergens') else 'No'}")
                    print(f"   - Nutrition items: {len(product_data.get('nutrition', {}))}")
                else:
                    print(f"❌ Failed to scrape: {product_data.get('product_name')}")
                
            except Exception as e:
                print(f"❌ Failed to scrape {url}: {str(e)}")
                results.append({
                    'url': url,
                    'product_name': f'Error: {str(e)}',
                    'product_details': '',
                    'ingredients': '',
                    'allergens': '',
                    'nutrition': {}
                })
        
        successful_scrapes = len([r for r in results if 'Error' not in r.get('product_name', '')])
        print(f"🎯 Successfully processed {successful_scrapes} products")
        
        for result in results:
            if 'Error' not in result.get('product_name', '') and result.get('nutrition'):
                print(f"📋 {result['product_name']} nutrition: {list(result['nutrition'].keys())}")
        
        return jsonify({'products': results})
        
    except Exception as e:
        print(f"❌ Error in process-urls: {str(e)}")
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/process-images', methods=['POST'])
def process_images():
    """Process uploaded product images - UPDATED FOR MULTIPLE PRODUCTS"""
    try:
        if 'images' not in request.files:
            return jsonify({'error': 'No images uploaded'}), 400
        
        files = request.files.getlist('images')
        product_names = request.form.getlist('product_names')
        
        if not files:
            return jsonify({'error': 'No images selected'}), 400
        
        print(f"🖼️ Processing {len(files)} images for {len(set(product_names))} products")
        
        product_files = defaultdict(lambda: {'ingredients': [], 'nutrition': []})
        
        temp_dir = tempfile.mkdtemp()
        temp_files = []
        
        try:
            for i, file in enumerate(files):
                if i < len(product_names):
                    product_name = product_names[i]
                else:
                    product_name = extract_product_name_from_filename(file.filename)
                
                filename = file.filename.lower()
                temp_path = os.path.join(temp_dir, filename)
                file.save(temp_path)
                temp_files.append(temp_path)
                
                if 'ingredient' in filename:
                    product_files[product_name]['ingredients'].append(temp_path)
                elif 'nutrient' in filename or 'nutrition' in filename:
                    product_files[product_name]['nutrition'].append(temp_path)
                else:
                    product_files[product_name]['ingredients'].append(temp_path)
            
            print(f"📦 Found {len(product_files)} products: {list(product_files.keys())}")
            
            products = []
            for product_name, file_groups in product_files.items():
                try:
                    print(f"🔍 Processing product: {product_name}")
                    print(f"   - Ingredients images: {len(file_groups['ingredients'])}")
                    print(f"   - Nutrition images: {len(file_groups['nutrition'])}")
                    
                    if not file_groups['ingredients'] and not file_groups['nutrition']:
                        print(f"⚠️ No valid images for {product_name}, skipping")
                        continue
                    
                    valid_ingredient_paths = [p for p in file_groups['ingredients'] if os.path.exists(p)]
                    valid_nutrition_paths = [p for p in file_groups['nutrition'] if os.path.exists(p)]
                    
                    if not valid_ingredient_paths and not valid_nutrition_paths:
                        print(f"⚠️ No valid image files found for {product_name}")
                        continue
                    
                    result = process_product(product_name, valid_ingredient_paths, valid_nutrition_paths)
                    
                    products.append({
                        'url': 'Image Upload',
                        'product_name': result['Product'],
                        'product_details': f'Processed from {len(file_groups["ingredients"]) + len(file_groups["nutrition"])} images',
                        'ingredients': result['Ingredients'],
                        'allergens': result['Allergens'],
                        'nutrition': json.loads(result['Nutrition'])
                    })
                    
                    print(f"✅ Successfully processed: {product_name}")
                    
                except Exception as product_error:
                    print(f"❌ Error processing {product_name}: {str(product_error)}")
                    traceback.print_exc()
                    products.append({
                        'url': 'Image Upload',
                        'product_name': product_name,
                        'product_details': f'Error: {str(product_error)}',
                        'ingredients': '',
                        'allergens': '',
                        'nutrition': {}
                    })
            
            if not products:
                return jsonify({'error': 'No products could be processed from the uploaded images'}), 400
            
            print(f"🎯 Successfully processed {len(products)} products from images")
            return jsonify({'products': products})
            
        finally:
            # Clean up temp files
            for temp_path in temp_files:
                if os.path.exists(temp_path):
                    try:
                        os.remove(temp_path)
                    except:
                        pass
            if os.path.exists(temp_dir):
                try:
                    os.rmdir(temp_dir)
                except:
                    pass
        
    except Exception as e:
        print(f"❌ Error in process-images: {str(e)}")
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

def extract_product_name_from_filename(filename):
    """Extract product name from filename"""
    name_without_ext = os.path.splitext(filename)[0]
    
    suffixes_to_remove = [
        '_ingredients', '_nutrients', '_nutrition', 
        '_ingredient', '_nutrient', 'ingredients', 'nutrients'
    ]
    
    product_name = name_without_ext
    for suffix in suffixes_to_remove:
        product_name = product_name.replace(suffix, '').replace(suffix.title(), '')
    
    product_name = product_name.replace('_', ' ').strip()
    if product_name:
        product_name = product_name.title()
    
    return product_name or 'Unknown Product'

@app.route('/api/analyze-products', methods=['POST'])
def analyze_products():
    """Analyze products based on health profile and generate medical recommendations"""
    try:
        print("🏥 Starting medical analysis...")
        data = request.json
        products = data.get('products', [])
        health_profile = data.get('health_profile', {})
        
        print(f"📊 Analyzing {len(products)} products with health profile: {health_profile}")
        
        if not products:
            return jsonify({'error': 'No products to analyze'}), 400
        
        valid_products = [p for p in products if 'Error' not in p.get('product_name', '')]
        print(f"✅ Valid products for analysis: {len(valid_products)}")
        
        if not valid_products:
            return jsonify({'error': 'No valid products to analyze'}), 400
        
        analyzed_products = []
        for product in valid_products:
            try:
                tags = nlp_tagger.generate_tags(product)
                
                health_analysis = scorer.analyze_product_health(product, health_profile)
                
                analyzed_products.append({
                    **product,
                    'tags': tags,
                    'health_analysis': health_analysis
                })
                
                print(f"✅ Medically analyzed: {product.get('product_name', 'Unknown')}")
                print(f"   - Recommendation: {health_analysis.get('overall_recommendation')}")
                print(f"   - Score: {health_analysis.get('overall_score', 0)}/100")
                
                if health_analysis.get('allergen_warnings'):
                    print(f"   🚫 Allergen warnings: {len(health_analysis['allergen_warnings'])}")
                if health_analysis.get('preference_warnings'):
                    print(f"   📋 Preference warnings: {len(health_analysis['preference_warnings'])}")
                if health_analysis.get('medical_warnings'):
                    print(f"   ⚠️  Medical warnings: {len(health_analysis['medical_warnings'])}")
                
            except Exception as product_error:
                print(f"❌ Error analyzing product {product.get('product_name', 'Unknown')}: {str(product_error)}")
                analyzed_products.append({
                    **product,
                    'tags': [],
                    'health_analysis': {
                        'overall_recommendation': 'Analysis Error',
                        'detailed_explanations': ['Product analysis unavailable due to technical error.'],
                        'medical_warnings': [],
                        'positive_factors': [],
                        'sources': [],
                        'preference_warnings': [],
                        'allergen_warnings': [],
                        'overall_score': 0
                    }
                })
        
        recommendation_priority = {
            'Highly Recommended - Excellent Choice': 1,
            'Moderately Suitable - Some Benefits': 2, 
            'Neutral - Limited Information': 3,
            'Use With Caution - Some Concerns': 4,
            'Not Recommended - Critical Health Risks': 5,
            'Not Recommended - Contains Allergens': 6,
            'Not Recommended - Violates Dietary Preferences': 7,
            'Analysis Error': 8
        }
        
        analyzed_products.sort(key=lambda x: (
            recommendation_priority.get(x['health_analysis']['overall_recommendation'], 3),
            -x['health_analysis'].get('overall_score', 0)  # Higher score first
        ))
        
        print(f"🎯 Medical analysis complete: {len(analyzed_products)} products analyzed")
        
        allergen_products = len([p for p in analyzed_products if p['health_analysis'].get('allergen_warnings')])
        preference_products = len([p for p in analyzed_products if p['health_analysis'].get('preference_warnings')])
        avg_score = sum(p['health_analysis'].get('overall_score', 0) for p in analyzed_products) / len(analyzed_products)
        
        print(f"📈 Summary - Allergen issues: {allergen_products}, Preference issues: {preference_products}, Avg score: {avg_score:.1f}")
        
        return jsonify({'ranked_products': analyzed_products})
        
    except Exception as e:
        print(f"❌ Error in medical analysis: {str(e)}")
        traceback.print_exc()
        return jsonify({'error': f'Medical analysis failed: {str(e)}'}), 500
    

@app.route('/api/health-rules', methods=['GET'])
def get_health_rules():
    """Get available health rules and conditions"""
    return jsonify({
        'conditions': rules_engine.get_available_conditions(),
        'restrictions': rules_engine.get_available_restrictions(),
        'allergens': [
            'gluten', 'dairy', 'nuts', 'peanuts', 'soy', 'eggs', 'fish', 'shellfish'
        ]
    })

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy', 
        'message': 'Healthy Food Ranker API is running',
        'engines_loaded': True
    })

@app.route('/api/debug', methods=['GET'])
def debug_info():
    return jsonify({
        'status': 'running',
        'engines_loaded': {
            'rules_engine': rules_engine is not None,
            'scorer': scorer is not None,
            'nlp_tagger': nlp_tagger is not None
        }
    })

if __name__ == '__main__':
    if not os.path.exists('frontend'):
        os.makedirs('frontend')
        os.makedirs('frontend/css')
        os.makedirs('frontend/js')
        print("Created frontend directory structure. Please add your HTML/CSS/JS files.")
    
    print("🚀 Starting Healthy Food Ranker Server...")
    print("📧 Access the application at: http://127.0.0.1:5000")
    app.run(debug=True, port=5002, host='0.0.0.0')