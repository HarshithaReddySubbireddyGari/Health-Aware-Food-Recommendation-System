import re 


class NLPTagger:
    def __init__(self):
        self.tag_patterns = {
            'High Sugar': [
                r'\b(sugar|sucrose|fructose|glucose|syrup)\b',
                r'added sugar', r'sweetener'
            ],
            'Low Sugar': [
                r'sugar\s*[<≤]\s*\d', r'no added sugar', r'unsweetened'
            ],
            'High Fiber': [
                r'high fiber', r'fiber.*\d+g', r'whole grain', r'whole wheat'
            ],
            'Low Sodium': [
                r'low sodium', r'reduced sodium', r'sodium.[<≤]\s\d+',
                r'no salt added', r'unsalted'
            ],
            'High Protein': [
                r'high protein', r'protein.*\d+g', r'protein rich'
            ],
            'Low Fat': [
                r'low fat', r'reduced fat', r'fat.[<≤]\s\d+',
                r'lean', r'skim'
            ],
            'Contains Additives': [
                r'\b(preservative|artificial|color|flavor|emulsifier)\b',
                r'\b(E\d{3,4})\b'
            ],
            'Natural': [
                r'natural', r'organic', r'no artificial', r'clean label'
            ],
            'Processed': [
                r'processed', r'refined', r'packaged', r'instant'
            ]
        }
    
    def generate_tags(self, product_data):
        """Generate tags based on product information"""
        tags = []
        
        text_to_analyze = f"{product_data.get('product_name', '')} {product_data.get('product_details', '')} {product_data.get('ingredients', '')}".lower()
        
        for tag, patterns in self.tag_patterns.items():
            for pattern in patterns:
                if re.search(pattern, text_to_analyze, re.IGNORECASE):
                    tags.append(tag)
                    break
        
        nutrition = product_data.get('nutrition', {})
        
        sugar = self._extract_nutrient_value(nutrition, 'sugar')
        if sugar and sugar > 10:
            tags.append('High Sugar')
        elif sugar and sugar < 5:
            tags.append('Low Sugar')
        
        fiber = self._extract_nutrient_value(nutrition, 'fiber')
        if fiber and fiber > 3:
            tags.append('High Fiber')
        
        sodium = self._extract_nutrient_value(nutrition, 'sodium')
        if sodium and sodium > 200:
            tags.append('High Sodium')
        elif sodium and sodium < 100:
            tags.append('Low Sodium')
        
        return list(set(tags))  
    
    def _extract_nutrient_value(self, nutrition, nutrient_name):
        """Extract numeric value from nutrition data"""
        import re
        for key, value in nutrition.items():
            if nutrient_name in key.lower():
                if isinstance(value, dict):
                    val_str = value.get('per_100g', '')
                else:
                    val_str = str(value)
                
                match = re.search(r'(\d+\.?\d*)', str(val_str))
                if match:
                    return float(match.group(1))
        return None