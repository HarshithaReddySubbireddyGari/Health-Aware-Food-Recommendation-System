import cv2
import os
import re
import json
import numpy as np
import easyocr

reader = easyocr.Reader(['en'], gpu=False)

def generate_preprocessed_variants(img_bgr, upscale=2):
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    gray_up = cv2.resize(gray, None, fx=upscale, fy=upscale, interpolation=cv2.INTER_CUBIC)

    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    sharp = clahe.apply(gray_up)
    sharp = cv2.fastNlMeansDenoising(sharp, h=30)
    blur = cv2.GaussianBlur(sharp, (0,0), sigmaX=3)
    sharp = cv2.addWeighted(sharp, 1.5, blur, -0.5, 0)

    smooth = cv2.bilateralFilter(gray_up, d=9, sigmaColor=75, sigmaSpace=75)
    smooth = cv2.fastNlMeansDenoising(smooth, h=20)

    return sharp, smooth

def ocr_boxes_on_img(img_gray):
    out = reader.readtext(img_gray, detail=1, paragraph=False)
    boxes = []
    for bbox, text, prob in out:
        xs = [p[0] for p in bbox]; ys = [p[1] for p in bbox]
        minx, maxx = min(xs), max(xs); miny, maxy = min(ys), max(ys)
        cx, cy = (minx+maxx)/2, (miny+maxy)/2
        boxes.append({
            "bbox": bbox, "text": text.strip(), "prob": prob,
            "minx": minx, "maxx": maxx, "miny": miny, "maxy": maxy,
            "cx": cx, "cy": cy, "w": maxx-minx, "h": maxy-miny
        })
    return boxes

def merge_box_lists(lists, dist_thresh=6):
    all_boxes = [b for lst in lists for b in lst]
    merged, used = [], [False]*len(all_boxes)
    for i, b in enumerate(all_boxes):
        if used[i]: continue
        group=[i]
        for j in range(i+1,len(all_boxes)):
            if used[j]: continue
            dx, dy = abs(all_boxes[j]["cx"]-b["cx"]), abs(all_boxes[j]["cy"]-b["cy"])
            if dx<=dist_thresh and dy<=dist_thresh:
                group.append(j); used[j]=True
        best=all_boxes[group[0]]
        for idx in group:
            cand=all_boxes[idx]
            if ('.' in cand["text"] and '.' not in best["text"]) or len(cand["text"])>len(best["text"]):
                best=cand
        merged.append(best)
    return merged

NUTRIENT_KEYWORDS = r"\b(energy|calor|protein|fat|saturat|trans|cholesterol|carbohy|sugar|sodium|salt|fiber|fibre|kcal|kj|mg|g)\b"

def find_table_bbox(boxes):
    candidates = [b for b in boxes if re.search(NUTRIENT_KEYWORDS, b["text"].lower()) or re.search(r"\d", b["text"])]
    if len(candidates)<3: return None
    minx=min(b["minx"] for b in candidates); miny=min(b["miny"] for b in candidates)
    maxx=max(b["maxx"] for b in candidates); maxy=max(b["maxy"] for b in candidates)
    w,h=maxx-minx, maxy-miny
    padx=max(8,int(0.06*w)); pady=max(8,int(0.06*h))
    return (max(0,int(minx-padx)), max(0,int(miny-pady)), int(maxx+padx), int(maxy+pady))

def group_boxes_into_rows(boxes,row_tol=None):
    if not boxes: return []
    boxes_sorted=sorted(boxes,key=lambda b:b["cy"])
    heights=[b["h"] for b in boxes_sorted if b["h"]>0]
    med_h=np.median(heights) if heights else 20
    if row_tol is None: row_tol=max(8,med_h*0.6)
    rows,current,prev_y=[],[boxes_sorted[0]],boxes_sorted[0]["cy"]
    for b in boxes_sorted[1:]:
        if abs(b["cy"]-prev_y)<=row_tol: current.append(b)
        else: rows.append(sorted(current,key=lambda x:x["cx"])); current=[b]
        prev_y=b["cy"]
    if current: rows.append(sorted(current,key=lambda x:x["cx"]))
    return rows

def compute_column_boundaries(rows,expected_cols=3):
    xs=sorted([b["cx"] for r in rows for b in r])
    if not xs: return []
    unique_x=sorted(set(int(x) for x in xs))
    k=min(expected_cols,len(unique_x))
    if k<=1: return []
    gaps=[(xs[i+1]-xs[i],i) for i in range(len(xs)-1)]
    gaps_sorted=sorted(gaps,key=lambda x:x[0],reverse=True)
    cut_idx=sorted([gaps_sorted[i][1] for i in range(k-1)]) if gaps_sorted else []
    groups=[]; start=0
    for idx in cut_idx:
        groups.append(xs[start:idx+1]); start=idx+1
    groups.append(xs[start:])
    centers=[np.mean(g) for g in groups if g]; centers=sorted(centers)
    return [(centers[i]+centers[i+1])/2.0 for i in range(len(centers)-1)]

def assign_col(cx,boundaries):
    if not boundaries: return 0
    for i,b in enumerate(boundaries):
        if cx<b: return i
    return len(boundaries)

NUM_RE = re.compile(r"([0-9]+(?:[.,][0-9]+)?)\s*([a-zA-Z%]+)?", re.IGNORECASE)

def parse_numeric_cell(text, nutrient_name=None):
    if not text:
        return ""
    t = text.replace(",", ".").strip()
    if not (nutrient_name and (nutrient_name.lower().endswith("(g)") or nutrient_name.lower().endswith("(9)"))):
        t = re.sub(r"^([0-9]+\.[0-9]*)(?<!\.9)9$", r"\1g", t)
    m = NUM_RE.search(t)
    if m:
        number = m.group(1)
        unit = m.group(2) or ""
        return f"{number}{unit}".strip()
    return t

def build_structured_rows_from_boxes(boxes, expected_cols=3):
    rows = group_boxes_into_rows(boxes)
    if not rows: return []
    boundaries = compute_column_boundaries(rows, expected_cols=expected_cols)
    structured = []
    for r in rows:
        cols = {}
        for b in r:
            ci = assign_col(b["cx"], boundaries)
            cols.setdefault(ci, []).append((b["cx"], b["text"]))
        max_col = max(cols.keys()) if cols else 0
        row_cells = []
        for ci in range(max_col + 1):
            if ci in cols:
                row_cells.append(" ".join([t for _, t in sorted(cols[ci], key=lambda x:x[0])]))
            else:
                row_cells.append("")
        structured.append(row_cells)
    return structured

def rows_to_nutrition(structured_rows):
    if not structured_rows: return {}
    header_idx=None
    for i,r in enumerate(structured_rows[:3]):
        comb=" ".join(c.lower() for c in r)
        if "per 100" in comb or "per serving" in comb:
            header_idx=i
            break
    if header_idx is None: header_idx=0
    ncols=max(len(r) for r in structured_rows)
    header=structured_rows[header_idx]
    per100_col=None
    serving_col=None
    for idx,cell in enumerate(header):
        c=cell.lower()
        if "100" in c: per100_col=idx
        if "serving" in c: serving_col=idx
    if per100_col is None and ncols>=2: per100_col=ncols-2
    if serving_col is None and ncols>=1: serving_col=ncols-1
    nutrient_col=0
    nutrition={}
    for i,r in enumerate(structured_rows):
        if i<=header_idx: continue
        r_ext=r+[""]*(max(0,max(nutrient_col,per100_col,serving_col)+1-len(r)))
        nut=r_ext[nutrient_col].strip()
        if not nut: continue
        nut=re.sub(r"[^A-Za-z0-9 %()./-]+", " ", nut).strip()
        per100=parse_numeric_cell(r_ext[per100_col], nutrient_name=nut) if per100_col is not None else ""
        pers=parse_numeric_cell(r_ext[serving_col], nutrient_name=nut) if serving_col is not None else ""
        nutrition[nut]={"per_100g":per100,"per_serving":pers}
    return nutrition

def parse_ingredients(text):
    m = re.search(
        r"(?:INGREDIENTS|CONTENTS)[:\-\s]*(.*?)(?=(?:ALLERGEN|CONTAINS|DECLARATION|NUTRIT|$))",
        text, re.IGNORECASE | re.DOTALL
    )
    cand = m.group(1) if m else text
    parts = [p.strip() for p in re.split(r",|\n|;|•", cand) if p.strip()]
    ingredients = []
    for p in parts:
        name = p.strip(" .:-")
        if name:
            ingredients.append(name)
    return ingredients

def parse_allergens(text):
    match=re.search(r"(ALLERGENS?|CONTAINS|DECLARATION)[:\-]?\s*(.*)",text,re.IGNORECASE)
    if not match: return []
    allergen_text=match.group(2)
    allergen_text=re.sub(r"(CONTAINS|MAY CONTAIN|ALLERGEN DECLARATION)","",allergen_text,flags=re.IGNORECASE)
    return [a.strip(" .") for a in re.split(r",|AND",allergen_text) if a.strip()]

def process_product(product_name, ingredient_image_paths, nutrition_image_paths):
    combined = []
    for ip in ingredient_image_paths:
        img = cv2.imread(ip)
        if img is None: continue
        sharp, smooth = generate_preprocessed_variants(img)
        txt_sharp = " ".join(reader.readtext(sharp, detail=0, paragraph=True) or [])
        txt_smooth = " ".join(reader.readtext(smooth, detail=0, paragraph=True) or [])
        combined.append(txt_sharp)
        combined.append(txt_smooth)
    combined_text = "\n".join(combined)
    ingredients = parse_ingredients(combined_text)
    allergens = parse_allergens(combined_text)

    all_structured = []
    for ni in nutrition_image_paths:
        img_full = cv2.imread(ni)
        if img_full is None: continue
        sharp_full, smooth_full = generate_preprocessed_variants(img_full)
        merged = merge_box_lists([ocr_boxes_on_img(sharp_full), ocr_boxes_on_img(smooth_full)], dist_thresh=8)
        bbox = find_table_bbox(merged)
        crop = img_full[bbox[1]:bbox[3], bbox[0]:bbox[2]] if bbox else img_full
        sharp_crop, smooth_crop = generate_preprocessed_variants(crop)
        merged_crop = merge_box_lists([ocr_boxes_on_img(sharp_crop), ocr_boxes_on_img(smooth_crop)], dist_thresh=6)
        struct = build_structured_rows_from_boxes(merged_crop, expected_cols=3)
        all_structured.extend(struct)

    nutrition = rows_to_nutrition(all_structured)

    return {
        "Product": product_name,
        "Ingredients": ", ".join(ingredients),
        "Allergens": ", ".join(allergens),
        "Nutrition": json.dumps(nutrition, ensure_ascii=False)
    }