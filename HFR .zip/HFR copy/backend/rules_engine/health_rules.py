
import re
import json

class HealthRulesEngine:
    def __init__(self):
        self.rules = self._load_comprehensive_rules()
    
    def _load_comprehensive_rules(self):
        """Load comprehensive health rules based on ALL your medical guidelines"""
        return {
            'diabetes': {
                'name': 'Diabetes (Type 1 & 2)',
                'severity': 'high',
                'nutrient_limits': {
                    'sugar': {'max_per_100g': 5, 'critical_max': 15},
                    'fiber': {'min_per_100g': 3, 'optimal_min': 5},
                    'saturated_fat': {'max_per_100g': 1.5}
                },
                'ingredient_rules': {
                    'avoid': ['added sugar', 'sucrose', 'fructose', 'glucose syrup', 'high fructose corn syrup', 'sugar-sweetened beverages'],
                    'prefer': ['whole grain', 'whole wheat', 'high fiber', 'complex carbs', 'legumes', 'fruits', 'vegetables', 'nuts'],
                    'critical_avoid': ['sugar-sweetened beverages', 'processed foods', 'fast foods']
                },
                'sources': [
                    'https://www.ncbi.nlm.nih.gov/books/NBK279012/',
                    'https://www.mayoclinic.org/diseases-conditions/diabetes/in-depth/diabetes-diet/art-20044295',
                    'https://www.niddk.nih.gov/health-information/diabetes/overview/healthy-living-with-diabetes'
                ]
            },

            'hypertension': {
                'name': 'High Blood Pressure',
                'severity': 'high',
                'nutrient_limits': {
                    'sodium': {'max_per_100g': 120, 'critical_max': 400},
                    'potassium': {'preferred': True}
                },
                'ingredient_rules': {
                    'avoid': ['salt', 'sodium', 'monosodium glutamate', 'baking soda', 'processed foods', 'cured meats'],
                    'prefer': ['low sodium', 'reduced sodium', 'unsalted', 'potassium', 'fruits', 'vegetables', 'whole grains'],
                    'critical_avoid': ['high sodium processed foods', 'fast foods', 'salty snacks']
                },
                'sources': [
                    'https://www.ahajournals.org/doi/10.1161/CIR.0000000000001146',
                    'https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure',
                    'https://www.nhlbi.nih.gov/education/dash-eating-plan'
                ]
            },

            'high_cholesterol': {
                'name': 'High Cholesterol',
                'severity': 'high',
                'nutrient_limits': {
                    'saturated_fat': {'max_per_100g': 1.5, 'critical_max': 3},
                    'fiber': {'min_per_100g': 3}
                },
                'ingredient_rules': {
                    'avoid': ['saturated fat', 'trans fat', 'hydrogenated', 'butter', 'lard', 'palm oil', 'coconut oil'],
                    'prefer': ['unsaturated fats', 'olive oil', 'omega-3', 'soluble fiber', 'oats', 'barley', 'legumes'],
                    'critical_avoid': ['partially hydrogenated oils', 'processed baked goods']
                },
                'sources': [
                    'https://www.heart.org/en/health-topics/cholesterol/prevention-and-treatment-of-high-cholesterol',
                    'https://www.mayoclinic.org/diseases-conditions/high-blood-cholesterol/in-depth/cholesterol/art-20045192',
                    'https://nutritionsource.hsph.harvard.edu/what-should-you-eat/fats-and-cholesterol/'
                ]
            },

            'celiac': {
                'name': 'Celiac Disease',
                'severity': 'critical',
                'ingredient_rules': {
                    'avoid': ['wheat', 'rye', 'barley', 'triticale', 'malt', 'brewer', 'graham', 'spelt', 'kamut'],
                    'prefer': ['gluten-free', 'certified gluten-free', 'rice', 'corn', 'quinoa', 'buckwheat'],
                    'critical_avoid': ['gluten-containing grains', 'contaminated oats']
                },
                'sources': [
                    'https://www.hopkinsmedicine.org/health/conditions-and-diseases/celiac-disease/dietary-changes-for-celiac-disease',
                    'https://www.niddk.nih.gov/health-information/digestive-diseases/celiac-disease/eating-diet-nutrition',
                    'https://celiac.org/gluten-free-living/gluten-free-foods/'
                ]
            },

            'lactose_intolerant': {
                'name': 'Lactose Intolerance',
                'severity': 'medium',
                'ingredient_rules': {
                    'avoid': ['milk', 'cream', 'cream cheese', 'cottage cheese', 'evaporated milk'],
                    'prefer': ['lactose-free', 'dairy-free', 'plant-based', 'aged cheeses', 'fermented dairy'],
                    'tolerated': ['yogurt with live cultures', 'hard cheeses']
                },
                'sources': [
                    'https://www.hopkinsmedicine.org/health/conditions-and-diseases/lactose-intolerance',
                    'https://www.niddk.nih.gov/health-information/digestive-diseases/lactose-intolerance/eating-diet-nutrition'
                ]
            },

            'obesity': {
                'name': 'Obesity / Weight Management',
                'severity': 'high',
                'nutrient_limits': {
                    'sugar': {'max_per_100g': 5},
                    'fiber': {'min_per_100g': 3},
                    'energy': {'moderate': True}
                },
                'ingredient_rules': {
                    'avoid': ['added sugars', 'high fructose corn syrup', 'processed foods', 'sugary beverages'],
                    'prefer': ['high fiber', 'whole grains', 'lean protein', 'fruits', 'vegetables']
                },
                'sources': [
                    'https://www.cdc.gov/healthy-weight-growth/healthy-eating/index.html',
                    'https://www.who.int/news-room/fact-sheets/detail/healthy-diet',
                    'https://www.ncbi.nlm.nih.gov/books/NBK574576/'
                ]
            },

            'kidney_issues': {
                'name': 'Kidney Issues',
                'severity': 'high',
                'nutrient_limits': {
                    'sodium': {'max_per_100g': 100},
                    'protein': {'moderate': True},
                    'potassium': {'moderate': True}
                },
                'ingredient_rules': {
                    'avoid': ['high sodium', 'excess protein', 'high potassium foods', 'oxalate-rich foods'],
                    'prefer': ['low sodium', 'moderate protein', 'plant proteins']
                },
                'sources': [
                    'https://www.kidney.org/kidney-topics/kidney-stone-diet-plan-and-prevention',
                    'https://www.niddk.nih.gov/health-information/urologic-diseases/kidney-stones/eating-diet-nutrition'
                ]
            },

            'thyroid_hypo': {
                'name': 'Thyroid Disorders (Hypothyroidism)',
                'severity': 'medium',
                'ingredient_rules': {
                    'prefer': ['iodine', 'selenium', 'zinc', 'iron', 'vitamin D'],
                    'moderate': ['soy', 'cruciferous vegetables'],
                    'avoid': ['excess iodine', 'raw cruciferous vegetables']
                },
                'sources': [
                    'https://www.healthline.com/nutrition/hypothyroidism-diet',
                    'https://health.clevelandclinic.org/hypothyroidism-diet'
                ]
            },

            'liver_fatty': {
                'name': 'Fatty Liver Disease',
                'severity': 'high',
                'nutrient_limits': {
                    'sugar': {'max_per_100g': 5},
                    'saturated_fat': {'max_per_100g': 1.5}
                },
                'ingredient_rules': {
                    'avoid': ['added sugars', 'high fructose corn syrup', 'alcohol', 'processed foods'],
                    'prefer': ['antioxidants', 'omega-3', 'fiber', 'whole grains', 'vegetables']
                },
                'sources': [
                    'https://www.niddk.nih.gov/health-information/liver-disease/nafld-nash',
                    'https://www.espen.org/files/ESPEN-Guidelines/ESPEN_practical_guideline_Clinical_nutrition_in_liver_disease.pdf'
                ]
            },

            'osteoporosis': {
                'name': 'Osteoporosis',
                'severity': 'medium',
                'nutrient_limits': {
                    'calcium': {'preferred': True},
                    'vitamin_d': {'preferred': True}
                },
                'ingredient_rules': {
                    'prefer': ['calcium', 'vitamin d', 'magnesium', 'vitamin k', 'protein']
                },
                'sources': [
                    'https://www.niams.nih.gov/health-topics/calcium-and-vitamin-d-important-bone-health',
                    'https://pmc.ncbi.nlm.nih.gov/articles/PMC9944083/'
                ]
            },

            'gout': {
                'name': 'Gout',
                'severity': 'medium',
                'ingredient_rules': {
                    'avoid': ['red meat', 'organ meats', 'shellfish', 'alcohol', 'sugary drinks'],
                    'prefer': ['low-fat dairy', 'plant proteins', 'cherries', 'whole grains']
                },
                'sources': [
                    'https://www.arthritis.org/health-wellness/healthy-living/nutrition/healthy-eating/which-foods-are-safe-for-gout',
                    'https://www.kidney.org/news-stories/what-to-eat-and-avoid-if-you-have-gout'
                ]
            },

            'ibs': {
                'name': 'Irritable Bowel Syndrome',
                'severity': 'medium',
                'nutrient_limits': {
                    'fiber': {'moderate': True}
                },
                'ingredient_rules': {
                    'avoid': ['high FODMAP foods', 'gluten', 'dairy', 'spicy foods', 'excess fat'],
                    'prefer': ['soluble fiber', 'low FODMAP', 'fermented foods', 'lean proteins']
                },
                'sources': [
                    'https://www.monashfodmap.com/about-fodmap-and-ibs/',
                    'https://www.nhs.uk/conditions/irritable-bowel-syndrome-ibs/diet-lifestyle-and-medicines/'
                ]
            }
        }

    def get_condition_rules(self, condition):
        """Get rules for specific health condition"""
        return self.rules.get(condition, {})

    def get_available_conditions(self):
        """Get list of available health conditions"""
        return {key: rule['name'] for key, rule in self.rules.items()}

    def get_available_restrictions(self):
        """Get list of available dietary restrictions"""
        return {
            'gluten_free': 'Gluten-Free',
            'dairy_free': 'Dairy-Free', 
            'vegan': 'Vegan',
            'vegetarian': 'Vegetarian',
            'low_sodium': 'Low Sodium',
            'low_sugar': 'Low Sugar',
            'low_fat': 'Low Fat',
            'high_protein': 'High Protein'
        }