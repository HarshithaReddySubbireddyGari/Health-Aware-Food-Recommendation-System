
from .health_rules import HealthRulesEngine
import re

class ProductScorer:
    def __init__(self):
        self.rules_engine = HealthRulesEngine()
    
    def analyze_product_health(self, product_data, health_profile):
        """COMPREHENSIVE medical analysis using ALL provided health rules"""
        nutrition = product_data.get('nutrition', {})
        ingredients = (product_data.get('ingredients', '') or '').lower()
        
        nutrient_values = self._extract_all_nutrients(nutrition)
        
        analysis_results = {
            'overall_recommendation': 'Neutral - Limited Information',
            'detailed_explanations': [],
            'medical_warnings': [],
            'positive_factors': [],
            'sources': [],
            'preference_warnings': [],
            'allergen_warnings': [],
            'overall_score': 0,
            'score_breakdown': {}
        }
        
        allergen_warnings = self._check_allergens(product_data, health_profile)
        analysis_results['allergen_warnings'].extend(allergen_warnings)
        
        preference_warnings = self._check_dietary_preferences(product_data, health_profile, nutrient_values)
        analysis_results['preference_warnings'].extend(preference_warnings)
        
        conditions = health_profile.get('conditions', {})
        
        for condition, is_active in conditions.items():
            if is_active:
                condition_analysis = self._analyze_for_condition(
                    condition, nutrient_values, ingredients, product_data
                )
                analysis_results['detailed_explanations'].extend(condition_analysis['reasons'])
                analysis_results['medical_warnings'].extend(condition_analysis['warnings'])
                analysis_results['positive_factors'].extend(condition_analysis['positives'])
                analysis_results['sources'].extend(condition_analysis['sources'])
        
        score_result = self._calculate_product_score(
            analysis_results, 
            health_profile, 
            nutrient_values, 
            ingredients
        )
        analysis_results['overall_score'] = score_result['score']
        analysis_results['score_breakdown'] = score_result['breakdown']
        
        analysis_results['overall_recommendation'] = self._generate_medical_recommendation(
            analysis_results['medical_warnings'], 
            analysis_results['positive_factors'],
            analysis_results['allergen_warnings'],
            analysis_results['preference_warnings']
        )
        
        return analysis_results
    
    def _check_allergens(self, product_data, health_profile):
        """Check if product contains user-specified allergens - IMPROVED LOGIC"""
        warnings = []
        user_allergens = health_profile.get('allergies', [])
        
        if not user_allergens:
            return warnings
        
        product_allergens = (product_data.get('allergens', '') or '').lower()
        ingredients = (product_data.get('ingredients', '') or '').lower()
        
        print(f"🔍 ALLERGEN CHECK: User allergens: {user_allergens}")
        print(f"🔍 ALLERGEN CHECK: Product allergens: {product_allergens}")
        print(f"🔍 ALLERGEN CHECK: Ingredients: {ingredients}")
        
        for allergen in user_allergens:
            allergen_lower = allergen.lower().strip()
            if allergen_lower in product_allergens:
                warnings.append({
                    'condition': 'allergy',
                    'severity': 'critical',
                    'message': f'❌ CONTAINS YOUR ALLERGEN: This product contains {allergen}',
                    'medical_fact': f'You have specified {allergen} as an allergen. This product should be avoided.',
                    'recommendation': 'STRICTLY AVOID - Contains your specified allergen'
                })
                print(f"🚫 ALLERGEN DETECTED: {allergen} found in product allergens")
            elif allergen_lower in ingredients:
                warnings.append({
                    'condition': 'allergy',
                    'severity': 'critical',
                    'message': f'❌ MAY CONTAIN YOUR ALLERGEN: Ingredients suggest presence of {allergen}',
                    'medical_fact': f'You have specified {allergen} as an allergen. Ingredients indicate possible presence.',
                    'recommendation': 'AVOID - May contain your specified allergen'
                })
                print(f"🚫 ALLERGEN DETECTED: {allergen} found in ingredients")
        
        return warnings
    
    def _check_dietary_preferences(self, product_data, health_profile, nutrients):
        """Check dietary restrictions and preferences"""
        warnings = []
        restrictions = health_profile.get('restrictions', {})
        
        if not restrictions:
            return warnings
        
        ingredients = (product_data.get('ingredients', '') or '').lower()
        
        if restrictions.get('gluten_free'):
            gluten_keywords = ['wheat', 'rye', 'barley', 'triticale', 'malt', 'brewer', 'graham', 'spelt', 'kamut']
            if any(keyword in ingredients for keyword in gluten_keywords):
                warnings.append({
                    'condition': 'preference',
                    'severity': 'critical',
                    'message': '❌ CONTAINS GLUTEN: Violates your gluten-free preference',
                    'medical_fact': 'Product contains gluten-containing ingredients',
                    'recommendation': 'Avoid if strictly gluten-free'
                })
        
        if restrictions.get('dairy_free'):
            dairy_keywords = ['milk', 'cream', 'cheese', 'yogurt', 'butter', 'whey', 'casein', 'lactose']
            if any(keyword in ingredients for keyword in dairy_keywords):
                warnings.append({
                    'condition': 'preference',
                    'severity': 'critical',
                    'message': '❌ CONTAINS DAIRY: Violates your dairy-free preference',
                    'medical_fact': 'Product contains dairy ingredients',
                    'recommendation': 'Avoid if strictly dairy-free'
                })
        
        if restrictions.get('vegan'):
            non_vegan_keywords = ['milk', 'cream', 'cheese', 'egg', 'honey', 'gelatin', 'whey', 'casein']
            if any(keyword in ingredients for keyword in non_vegan_keywords):
                warnings.append({
                    'condition': 'preference',
                    'severity': 'critical',
                    'message': '❌ NOT VEGAN: Contains animal products',
                    'medical_fact': 'Product contains animal-derived ingredients',
                    'recommendation': 'Avoid if strictly vegan'
                })
        
        if restrictions.get('vegetarian'):
            non_veg_keywords = ['meat', 'beef', 'chicken', 'pork', 'fish', 'gelatin']
            if any(keyword in ingredients for keyword in non_veg_keywords):
                warnings.append({
                    'condition': 'preference',
                    'severity': 'critical',
                    'message': '❌ NOT VEGETARIAN: Contains meat products',
                    'medical_fact': 'Product contains meat or animal flesh',
                    'recommendation': 'Avoid if vegetarian'
                })
        
        if restrictions.get('low_sodium'):
            sodium = nutrients.get('sodium')
            if sodium is not None and sodium > 140:  
                warnings.append({
                    'condition': 'preference',
                    'severity': 'medium',
                    'message': f'⚠️ HIGH SODIUM: {sodium}mg exceeds low-sodium preference',
                    'medical_fact': 'Product sodium content is higher than low-sodium guidelines',
                    'recommendation': 'Consider lower sodium alternatives'
                })
        
        if restrictions.get('low_sugar'):
            sugar = nutrients.get('sugar')
            if sugar is not None and sugar > 5: 
                warnings.append({
                    'condition': 'preference',
                    'severity': 'medium',
                    'message': f'⚠️ HIGH SUGAR: {sugar}g exceeds low-sugar preference',
                    'medical_fact': 'Product sugar content is higher than low-sugar guidelines',
                    'recommendation': 'Consider lower sugar alternatives'
                })
        
        if restrictions.get('low_fat'):
            fat = nutrients.get('fat')
            if fat is not None and fat > 3:  
                warnings.append({
                    'condition': 'preference',
                    'severity': 'medium',
                    'message': f'⚠️ HIGH FAT: {fat}g exceeds low-fat preference',
                    'medical_fact': 'Product fat content is higher than low-fat guidelines',
                    'recommendation': 'Consider lower fat alternatives'
                })
        
        if restrictions.get('high_protein'):
            protein = nutrients.get('protein')
            if protein is not None and protein < 10:  
                warnings.append({
                    'condition': 'preference',
                    'severity': 'low',
                    'message': f'📉 LOW PROTEIN: {protein}g does not meet high-protein preference',
                    'medical_fact': 'Product protein content is lower than high-protein guidelines',
                    'recommendation': 'Consider higher protein alternatives'
                })
        
        return warnings
    
    def _calculate_product_score(self, analysis_results, health_profile, nutrients, ingredients):
        """Calculate comprehensive product score with detailed breakdown - UPDATED BASE SCORE TO 50"""
        score = 50  
        breakdown = {}
        
        print(f"\n🎯 SCORING ANALYSIS FOR PRODUCT")
        print("=" * 50)
        
        allergen_penalty = len(analysis_results['allergen_warnings']) * 50
        if allergen_penalty > 0:
            score -= allergen_penalty
            breakdown['allergen_penalty'] = -allergen_penalty
            print(f"🚫 Allergen Penalty: -{allergen_penalty} (CRITICAL)")
        
        preference_penalty = 0
        for warning in analysis_results['preference_warnings']:
            if warning.get('severity') == 'critical':
                preference_penalty += 30
            elif warning.get('severity') == 'high':
                preference_penalty += 20
            elif warning.get('severity') == 'medium':
                preference_penalty += 15
            else:
                preference_penalty += 5
        
        if preference_penalty > 0:
            score -= preference_penalty
            breakdown['preference_penalty'] = -preference_penalty
            print(f"📋 Preference Penalty: -{preference_penalty}")
        
        medical_penalty = 0
        for warning in analysis_results['medical_warnings']:
            if warning.get('severity') == 'critical':
                medical_penalty += 25
            elif warning.get('severity') == 'high':
                medical_penalty += 20
            elif warning.get('severity') == 'medium':
                medical_penalty += 10
            else:
                medical_penalty += 5
        
        if medical_penalty > 0:
            score -= medical_penalty
            breakdown['medical_penalty'] = -medical_penalty
            print(f"⚠️ Medical Warning Penalty: -{medical_penalty}")
        
        positive_bonus = len(analysis_results['positive_factors']) * 8
        if positive_bonus > 0:
            score += positive_bonus
            breakdown['positive_bonus'] = +positive_bonus
            print(f"💚 Positive Factors Bonus: +{positive_bonus}")
        
        nutrient_score = self._calculate_nutrient_score(nutrients, health_profile)
        score += nutrient_score
        breakdown['nutrient_score'] = nutrient_score
        print(f"📊 Nutrient Analysis Score: +{nutrient_score}")
        
        score = max(0, min(100, score))
        
        breakdown['final_score'] = score
        print(f"🎯 FINAL SCORE: {score}/100")
        print("=" * 50)
        
        return {
            'score': round(score),
            'breakdown': breakdown
        }
    
    def _calculate_nutrient_score(self, nutrients, health_profile):
        """Calculate score based on nutrient content and health profile"""
        nutrient_score = 0
        
        sugar = nutrients.get('sugar', 0)
        sodium = nutrients.get('sodium', 0)
        fiber = nutrients.get('fiber', 0)
        protein = nutrients.get('protein', 0)
        saturated_fat = nutrients.get('saturated_fat', 0)
        
        if sugar is not None:
            if sugar <= 5:
                nutrient_score += 10
            elif sugar <= 10:
                nutrient_score += 5
            elif sugar > 20:
                nutrient_score -= 10
        
        if sodium is not None:
            if sodium <= 140:
                nutrient_score += 10
            elif sodium <= 200:
                nutrient_score += 5
            elif sodium > 400:
                nutrient_score -= 10
        
        if fiber is not None:
            if fiber >= 5:
                nutrient_score += 10
            elif fiber >= 3:
                nutrient_score += 5
        
        if protein is not None:
            if protein >= 10:
                nutrient_score += 5
        
        if saturated_fat is not None:
            if saturated_fat <= 1:
                nutrient_score += 5
            elif saturated_fat > 3:
                nutrient_score -= 5
        
        conditions = health_profile.get('conditions', {})
        
        if conditions.get('diabetes'):
            carbs = nutrients.get('carbohydrate', 0)
            if carbs is not None:
                if carbs <= 15:
                    nutrient_score += 5
                elif carbs > 30:
                    nutrient_score -= 5
        
        if conditions.get('hypertension'):
            if sodium is not None and sodium > 200:
                nutrient_score -= 8
        
        if conditions.get('high_cholesterol'):
            if saturated_fat is not None and saturated_fat > 2:
                nutrient_score -= 8
        
        return nutrient_score
    
    def _analyze_for_condition(self, condition, nutrients, ingredients, product_data):
        """COMPLETE medical analysis for each condition using YOUR exact rules"""
        analysis = {
            'reasons': [],
            'warnings': [],
            'positives': [],
            'sources': []
        }
        
        sugar = nutrients.get('sugar')
        fiber = nutrients.get('fiber')
        sodium = nutrients.get('sodium')
        saturated_fat = nutrients.get('saturated_fat')
        protein = nutrients.get('protein')
        carbs = nutrients.get('carbohydrate')
        energy = nutrients.get('energy')
        
        if condition == 'diabetes':
            analysis.update(self._analyze_diabetes_comprehensive(sugar, fiber, carbs, energy, ingredients, nutrients))
        
        elif condition == 'hypertension':
            analysis.update(self._analyze_hypertension_comprehensive(sodium, ingredients, nutrients))
        
        elif condition == 'high_cholesterol':
            analysis.update(self._analyze_cholesterol_comprehensive(saturated_fat, fiber, ingredients, nutrients))
        
        elif condition == 'celiac':
            analysis.update(self._analyze_celiac_comprehensive(ingredients))
        
        elif condition == 'lactose_intolerant':
            analysis.update(self._analyze_lactose_comprehensive(ingredients))
        
        elif condition == 'obesity':
            analysis.update(self._analyze_obesity_comprehensive(sugar, fiber, protein, energy, ingredients))
        
        elif condition == 'kidney_issues':
            analysis.update(self._analyze_kidney_comprehensive(sodium, protein, nutrients, ingredients))
        
        elif condition == 'thyroid_hypo':
            analysis.update(self._analyze_thyroid_comprehensive(ingredients))
        
        elif condition == 'liver_fatty':
            analysis.update(self._analyze_liver_comprehensive(sugar, saturated_fat, ingredients))
        
        elif condition == 'osteoporosis':
            analysis.update(self._analyze_osteoporosis_comprehensive(nutrients, ingredients))
        
        elif condition == 'gout':
            analysis.update(self._analyze_gout_comprehensive(ingredients, nutrients))
        
        elif condition == 'ibs':
            analysis.update(self._analyze_ibs_comprehensive(fiber, ingredients))
            
        return analysis
    
    def _analyze_diabetes_comprehensive(self, sugar, fiber, carbs, energy, ingredients, nutrients):
        """COMPLETE diabetes analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        print(f"🔍 DIABETES ANALYSIS - Sugar: {sugar}g, Carbs: {carbs}g, Fiber: {fiber}g")
        
        if sugar is not None:
            if sugar > 15:
                warnings.append({
                    'condition': 'diabetes',
                    'severity': 'critical',
                    'message': f'❌ DANGEROUS FOR DIABETES: Very high sugar ({sugar}g) - exceeds medical threshold for diabetes risk',
                    'medical_fact': 'High sugar intake related to weight gain and diabetes risk. Added sugars and sugar-sweetened beverages increase blood sugar and weight gain',
                    'recommendation': 'STRICTLY AVOID - can cause dangerous blood glucose spikes'
                })
            elif sugar > 5:
                warnings.append({
                    'condition': 'diabetes',
                    'severity': 'medium', 
                    'message': f'⚠️ MODERATE DIABETES RISK: High sugar ({sugar}g) - exceeds optimal limit for diabetes management',
                    'medical_fact': 'Limit foods with added sugars. Sucrose associated with weight gain and dental caries',
                    'recommendation': 'Consume with caution and glucose monitoring'
                })
            elif sugar < 2:
                positives.append({
                    'condition': 'diabetes',
                    'message': f'✅ EXCELLENT FOR DIABETES: Very low sugar ({sugar}g) - prevents hyperglycemia',
                    'medical_fact': 'Minimizes glucose load preventing pancreatic beta-cell stress and insulin resistance',
                    'benefit': 'Maintains stable blood glucose and reduces HbA1c levels'
                })
        
        if carbs is not None:
            if carbs > 30:
                warnings.append({
                    'condition': 'diabetes',
                    'severity': 'medium',
                    'message': f'⚠️ HIGH CARBOHYDRATE CONTENT: {carbs}g carbs - monitor portion size for diabetes',
                    'medical_fact': 'High carbohydrate foods can raise blood glucose levels significantly',
                    'recommendation': 'Consume in controlled portions with protein/fat to slow absorption'
                })
            elif carbs < 10:
                positives.append({
                    'condition': 'diabetes',
                    'message': f'✅ LOW CARBOHYDRATE: {carbs}g carbs - suitable for diabetes management',
                    'medical_fact': 'Lower carbohydrate content helps maintain stable blood glucose levels',
                    'benefit': 'Reduces postprandial glucose spikes'
                })
        
        if fiber is not None:
            if fiber >= 5:
                positives.append({
                    'condition': 'diabetes',
                    'message': f'✅ IDEAL FIBER FOR DIABETES: High fiber ({fiber}g) - meets medical recommendations',
                    'medical_fact': 'Fiber ≥14g/1000 kcal linked to lower mortality, better glucose control in diabetes. High fiber intake improves insulin sensitivity',
                    'benefit': 'Slows carbohydrate absorption, reduces postprandial glucose spikes'
                })
            elif fiber >= 3:
                positives.append({
                    'condition': 'diabetes',
                    'message': f'✅ GOOD FIBER FOR DIABETES: Adequate fiber ({fiber}g) supports blood sugar control',
                    'medical_fact': 'Dietary fiber from whole grains, legumes, fruits, vegetables, nuts improves metabolic health',
                    'benefit': 'Promotes satiety and reduces overall calorie intake'
                })
        
        if 'whole grain' in ingredients or 'whole wheat' in ingredients:
            positives.append({
                'condition': 'diabetes',
                'message': '✅ EXCELLENT CARBOHYDRATE SOURCE: Contains whole grains - recommended for diabetes',
                'medical_fact': 'Emphasize nutrient-dense, high-fiber sources like whole grains, legumes, fruits, vegetables',
                'benefit': 'Provides complex carbohydrates for gradual glucose release'
            })
        elif 'refined' in ingredients or 'white flour' in ingredients:
            warnings.append({
                'condition': 'diabetes',
                'severity': 'medium',
                'message': '⚠️ POOR CARBOHYDRATE QUALITY: Contains refined grains - not ideal for diabetes',
                'medical_fact': 'Avoid sugar-sweetened beverages and choose minimally processed carbs',
                'recommendation': 'Choose whole grain alternatives when possible'
            })
        
        added_sugar_keywords = ['added sugar', 'sucrose', 'high fructose corn syrup', 'corn syrup', 'glucose syrup']
        if any(keyword in ingredients for keyword in added_sugar_keywords):
            warnings.append({
                'condition': 'diabetes',
                'severity': 'high',
                'message': '❌ ADDED SUGARS DETECTED: Contains added sweeteners that impact blood glucose',
                'medical_fact': 'Limit added fructose to <12% of energy. Added fructose especially in beverages may have harmful metabolic effects',
                'recommendation': 'Limit consumption and monitor blood glucose levels carefully'
            })
        
        if 'saturated fat' in ingredients or 'hydrogenated' in ingredients:
            warnings.append({
                'condition': 'diabetes',
                'severity': 'medium',
                'message': '⚠️ UNHEALTHY FATS: Contains saturated/trans fats',
                'medical_fact': 'Limit saturated fats <10% total energy intake. Trans fats increase mortality and heart disease risk',
                'recommendation': 'Choose products with monounsaturated fats (avocado, olive, canola oils, nuts, fish oils)'
            })
        elif 'olive oil' in ingredients or 'avocado' in ingredients or 'nuts' in ingredients:
            positives.append({
                'condition': 'diabetes',
                'message': '✅ HEALTHY FATS: Contains monounsaturated fats - recommended for diabetes',
                'medical_fact': 'Monounsaturated fats improve cardiovascular risk and metabolic control. Mediterranean diet fats preferred',
                'benefit': 'Supports heart health and insulin sensitivity'
            })
        
        if 'legumes' in ingredients or 'lentils' in ingredients or 'tofu' in ingredients:
            positives.append({
                'condition': 'diabetes',
                'message': '✅ EXCELLENT PROTEIN SOURCE: Plant-based proteins recommended for diabetes',
                'medical_fact': 'Plant based proteins encouraged: legumes, lentils, tofu, nuts, seeds. 1–1.5 g/kg/day typical',
                'benefit': 'Supports metabolic health without saturated fats'
            })
        elif 'processed meat' in ingredients or 'bacon' in ingredients or 'sausage' in ingredients:
            warnings.append({
                'condition': 'diabetes',
                'severity': 'medium',
                'message': '⚠️ PROCESSED MEAT DETECTED: Not ideal for diabetes management',
                'medical_fact': 'High intake of red and processed meats associated with worse health outcomes',
                'recommendation': 'Choose lean meats, fish, low-fat dairy instead'
            })
        
        sources.extend([
            'https://www.ncbi.nlm.nih.gov/books/NBK279012/',
            'https://www.mayoclinic.org/diseases-conditions/diabetes/in-depth/diabetes-diet/art-20044295', 
            'https://www.niddk.nih.gov/health-information/diabetes/overview/healthy-living-with-diabetes'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }
    
    def _analyze_hypertension_comprehensive(self, sodium, ingredients, nutrients):
        """COMPLETE hypertension analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        print(f"🔍 HYPERTENSION ANALYSIS - Sodium: {sodium}mg")
        
        if sodium is not None:
            if sodium > 400:
                warnings.append({
                    'condition': 'hypertension',
                    'severity': 'critical',
                    'message': f'❌ DANGEROUS FOR HYPERTENSION: Extremely high sodium ({sodium}mg)',
                    'medical_fact': 'Excess salt from processed foods, restaurant foods increases hypertension risk. Recommended <2300 mg/day, ideally <1500 mg/day',
                    'recommendation': 'STRICTLY AVOID - can cause immediate blood pressure elevation'
                })
            elif sodium > 200:
                warnings.append({
                    'condition': 'hypertension',
                    'severity': 'high',
                    'message': f'⚠️ HIGH SODIUM CONCERN: Elevated sodium ({sodium}mg)',
                    'medical_fact': 'Limit sodium intake to manage blood pressure. Excess from processed foods increases hypertension risk',
                    'recommendation': 'Consume very sparingly with careful BP monitoring'
                })
            elif sodium < 120:
                positives.append({
                    'condition': 'hypertension',
                    'message': f'✅ EXCELLENT FOR BLOOD PRESSURE: Low sodium ({sodium}mg)',
                    'medical_fact': 'Low sodium intake supports blood pressure control. DASH diet recommended for hypertension and diabetes',
                    'benefit': 'Reduces cardiovascular strain and stroke risk'
                })
        
        if 'potassium' in ingredients:
            positives.append({
                'condition': 'hypertension',
                'message': '✅ BLOOD PRESSURE SUPPORT: Contains potassium - counters sodium effects',
                'medical_fact': 'High intake helps regulate blood pressure. Recommended ~4.7 g/day; high potassium-to-sodium ratio beneficial',
                'benefit': 'Promotes sodium excretion and endothelial function'
            })
        
        dash_positive_keywords = ['whole grain', 'fruits', 'vegetables', 'low-fat dairy', 'nuts', 'legumes']
        if any(keyword in ingredients for keyword in dash_positive_keywords):
            positives.append({
                'condition': 'hypertension',
                'message': '✅ DASH DIET COMPATIBLE: Contains components recommended for blood pressure control',
                'medical_fact': 'DASH eating plan emphasizes fruits, vegetables, whole grains, lean proteins',
                'benefit': 'Provides potassium, calcium, magnesium and fiber that support vascular health'
            })
        
        processed_keywords = ['processed', 'cured', 'fast food', 'ultraprocessed']
        if any(keyword in ingredients for keyword in processed_keywords):
            warnings.append({
                'condition': 'hypertension',
                'severity': 'medium',
                'message': '⚠️ PROCESSED FOOD CONCERN: May contain hidden sodium and unhealthy fats',
                'medical_fact': 'Processed/ultraprocessed foods high in sodium, saturated/trans fats, sugars should be avoided or limited',
                'recommendation': 'Choose fresh, low-sodium alternatives'
            })
        
        if 'saturated fat' in ingredients or 'trans fat' in ingredients:
            warnings.append({
                'condition': 'hypertension',
                'severity': 'medium',
                'message': '⚠️ UNHEALTHY FATS DETECTED: May negatively impact cardiovascular health',
                'medical_fact': 'Avoid saturated fats, trans fats, tropical oils (coconut, palm). Prefer unsaturated fats (olive, canola, safflower oils)',
                'recommendation': 'Choose products with plant-based oils'
            })
        
        sources.extend([
            'https://www.ahajournals.org/doi/10.1161/CIR.0000000000001146',
            'https://www.heart.org/en/health-topics/high-blood-pressure/changes-you-can-make-to-manage-high-blood-pressure',
            'https://www.nhlbi.nih.gov/education/dash-eating-plan'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }
    
    def _analyze_cholesterol_comprehensive(self, saturated_fat, fiber, ingredients, nutrients):
        """COMPLETE cholesterol analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        print(f"🔍 CHOLESTEROL ANALYSIS - Saturated Fat: {saturated_fat}g, Fiber: {fiber}g")
        
        if saturated_fat is not None:
            if saturated_fat > 3:
                warnings.append({
                    'condition': 'high_cholesterol',
                    'severity': 'high',
                    'message': f'❌ HIGH CHOLESTEROL RISK: High saturated fat ({saturated_fat}g)',
                    'medical_fact': 'Saturated fats raise LDL cholesterol. Butter, red meats, high-fat dairy, coconut and palm oil associated with increased LDL cholesterol and CVD risk',
                    'recommendation': 'Limit intake and choose unsaturated fat alternatives'
                })
            elif saturated_fat > 1.5:
                warnings.append({
                    'condition': 'high_cholesterol',
                    'severity': 'medium',
                    'message': f'⚠️ MODERATE SATURATED FAT: {saturated_fat}g - monitor intake for cholesterol',
                    'medical_fact': 'Saturated fats should be limited to <10% of total calories for heart health',
                    'recommendation': 'Consume in moderation'
                })
            elif saturated_fat < 1.5:
                positives.append({
                    'condition': 'high_cholesterol',
                    'message': f'✅ HEART-HEALTHY: Low saturated fat ({saturated_fat}g)',
                    'medical_fact': 'Limiting saturated fats supports healthy cholesterol levels. Limit <10% total energy intake',
                    'benefit': 'Reduces LDL cholesterol and cardiovascular risk'
                })
        
        if fiber is not None:
            if fiber > 3:
                positives.append({
                    'condition': 'high_cholesterol',
                    'message': f'✅ CHOLESTEROL MANAGEMENT: Good fiber ({fiber}g)',
                    'medical_fact': 'Soluble fiber 5-10+ grams per day binds bile/cholesterol in intestines lowering LDL by ~5-10%',
                    'benefit': 'Reduces cholesterol absorption and supports heart health'
                })
        
        if 'olive oil' in ingredients or 'avocado' in ingredients or 'nuts' in ingredients:
            positives.append({
                'condition': 'high_cholesterol',
                'message': '✅ HEART-HEALTHY FATS: Contains monounsaturated fats',
                'medical_fact': 'Monounsaturated fats (olive oil, avocados, nuts) improve LDL, support HDL. Mediterranean diet full of MUFA linked to lower CVD risk',
                'benefit': 'Improves lipid profile and reduces cardiovascular risk'
            })
        
        if 'hydrogenated' in ingredients or 'partially hydrogenated' in ingredients:
            warnings.append({
                'condition': 'high_cholesterol',
                'severity': 'critical',
                'message': '❌ TRANS FATS DETECTED: Extremely harmful for cholesterol',
                'medical_fact': 'Trans fatty acids raise LDL, lower HDL cholesterol; strongest dietary contributor to CVD risk; largely banned in food supply',
                'recommendation': 'STRICTLY AVOID - choose products without hydrogenated oils'
            })
        
        if 'whole grain' in ingredients or 'oats' in ingredients or 'barley' in ingredients:
            positives.append({
                'condition': 'high_cholesterol',
                'message': '✅ CHOLESTEROL-LOWERING: Contains whole grains with beneficial fibers',
                'medical_fact': 'Whole grains high in fiber improve lipid metabolism. Oats, barley, legumes contain soluble fiber that binds cholesterol',
                'benefit': 'Supports healthy cholesterol levels through multiple mechanisms'
            })
        
        sources.extend([
            'https://www.heart.org/en/health-topics/cholesterol/prevention-and-treatment-of-high-cholesterol',
            'https://www.mayoclinic.org/diseases-conditions/high-blood-cholesterol/in-depth/cholesterol/art-20045192',
            'https://nutritionsource.hsph.harvard.edu/what-should-you-eat/fats-and-cholesterol/'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }

    def _analyze_celiac_comprehensive(self, ingredients):
        """COMPLETE celiac disease analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        gluten_keywords = ['wheat', 'rye', 'barley', 'triticale', 'malt', 'brewer', 'graham', 'spelt', 'kamut']
        gluten_found = any(keyword in ingredients for keyword in gluten_keywords)
        
        if gluten_found:
            warnings.append({
                'condition': 'celiac',
                'severity': 'critical',
                'message': '❌ UNSAFE FOR CELIAC DISEASE: Contains gluten-containing ingredients',
                'medical_fact': 'Gluten proteins (gliadin in wheat, hordein in barley, secalin in rye) cause autoimmune damage; strict avoidance mandatory',
                'recommendation': 'STRICTLY AVOID - even trace amounts can damage intestinal mucosa'
            })
        else:
            positives.append({
                'condition': 'celiac',
                'message': '✅ GLUTEN-FREE: No detectable gluten-containing ingredients',
                'medical_fact': 'Safe for celiac disease when no wheat, rye, barley, triticale, or contaminated ingredients present',
                'benefit': 'Prevents intestinal damage and autoimmune complications'
            })
        
        hidden_gluten_keywords = ['modified food starch', 'dextrin', 'maltodextrin', 'natural flavors']
        if any(keyword in ingredients for keyword in hidden_gluten_keywords):
            warnings.append({
                'condition': 'celiac',
                'severity': 'high',
                'message': '⚠️ POTENTIAL HIDDEN GLUTEN: May contain gluten-derived ingredients',
                'medical_fact': 'Hidden gluten common in processed foods, sauces, dressings, malt-containing flavorings',
                'recommendation': 'Verify gluten-free certification or contact manufacturer'
            })
        
        sources.extend([
            'https://www.hopkinsmedicine.org/health/conditions-and-diseases/celiac-disease/dietary-changes-for-celiac-disease',
            'https://www.niddk.nih.gov/health-information/digestive-diseases/celiac-disease/eating-diet-nutrition',
            'https://celiac.org/gluten-free-living/gluten-free-foods/'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }

    def _analyze_lactose_comprehensive(self, ingredients):
        """COMPLETE lactose intolerance analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        high_lactose_keywords = ['milk', 'cream', 'cream cheese', 'cottage cheese', 'evaporated milk', 'condensed milk']
        if any(keyword in ingredients for keyword in high_lactose_keywords):
            warnings.append({
                'condition': 'lactose_intolerant',
                'severity': 'high',
                'message': '⚠️ HIGH LACTOSE CONTENT: Contains dairy products with significant lactose',
                'medical_fact': 'Regular milk (~4.9-5.3 g lactose/100ml), cream, sour cream, cream cheese, evaporated/sweetened condensed milk contain significant lactose',
                'recommendation': 'May cause digestive discomfort; choose lactose-free alternatives'
            })
        
        low_lactose_keywords = ['aged cheese', 'parmesan', 'cheddar', 'swiss', 'gouda', 'lactose-free']
        if any(keyword in ingredients for keyword in low_lactose_keywords):
            positives.append({
                'condition': 'lactose_intolerant',
                'message': '✅ LACTOSE-FRIENDLY: Contains low-lactose or lactose-free dairy',
                'medical_fact': 'Aged hard cheeses like Parmesan, Pecorino, Swiss, Cheddar, Gouda contain minimal lactose due to fermentation and whey removal',
                'benefit': 'Generally well tolerated by most lactose intolerant individuals'
            })
        
        dairy_alternative_keywords = ['soy milk', 'almond milk', 'rice milk', 'oat milk', 'coconut milk', 'plant-based']
        if any(keyword in ingredients for keyword in dairy_alternative_keywords):
            positives.append({
                'condition': 'lactose_intolerant',
                'message': '✅ DAIRY-FREE ALTERNATIVE: Safe for lactose intolerance',
                'medical_fact': 'Fortified soy milk, almond, rice, oat, hemp, coconut milks are suitable lactose-free alternatives',
                'benefit': 'Provides dairy-free nutrition without lactose discomfort'
            })
        
        sources.extend([
            'https://www.hopkinsmedicine.org/health/conditions-and-diseases/lactose-intolerance',
            'https://www.niddk.nih.gov/health-information/digestive-diseases/lactose-intolerance/eating-diet-nutrition',
            'https://www.mayoclinic.org/diseases-conditions/lactose-intolerance/diagnosis-treatment/drc-20374238'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }

    def _analyze_obesity_comprehensive(self, sugar, fiber, protein, energy, ingredients):
        """COMPLETE obesity analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        if sugar is not None and sugar > 10:
            warnings.append({
                'condition': 'obesity',
                'severity': 'high',
                'message': f'⚠️ WEIGHT MANAGEMENT CONCERN: High sugar ({sugar}g)',
                'medical_fact': 'Added sugars <10% of total energy intake (ideally <5%). Sugary beverages, processed snacks, and desserts contribute to weight gain',
                'recommendation': 'Limit consumption for effective weight management'
            })
        
        if fiber is not None and fiber > 3:
            positives.append({
                'condition': 'obesity',
                'message': f'✅ WEIGHT MANAGEMENT SUPPORT: Good fiber ({fiber}g) promotes satiety',
                'medical_fact': 'High-fiber diets increase satiety & improve metabolic health. Recommended ≥14g/1000 kcal; associated with reduced weight and improved insulin sensitivity',
                'benefit': 'Promotes fullness and reduces overall calorie intake'
            })
        
        if 'lean protein' in ingredients or 'plant protein' in ingredients:
            positives.append({
                'condition': 'obesity',
                'message': '✅ SATIETY SUPPORT: Contains protein that improves satiety',
                'medical_fact': 'Moderately high protein (plant and animal sources) improves satiety and energy expenditure. ~25-35% energy from protein in low-carb diets',
                'benefit': 'Supports muscle maintenance during weight loss'
            })
        
        if 'whole grain' in ingredients or 'oats' in ingredients or 'quinoa' in ingredients:
            positives.append({
                'condition': 'obesity',
                'message': '✅ METABOLIC HEALTH: Contains whole grains that improve satiety',
                'medical_fact': 'Whole grains emphasized: oats, barley, quinoa. Whole grains improve metabolic health and satiety',
                'benefit': 'Provides sustained energy and reduces hunger between meals'
            })
        
        sources.extend([
            'https://www.cdc.gov/healthy-weight-growth/healthy-eating/index.html',
            'https://www.who.int/news-room/fact-sheets/detail/healthy-diet',
            'https://www.ncbi.nlm.nih.gov/books/NBK574576/'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }

    def _analyze_kidney_comprehensive(self, sodium, protein, nutrients, ingredients):
        """COMPLETE kidney issues analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        if sodium is not None and sodium > 100:
            warnings.append({
                'condition': 'kidney_issues',
                'severity': 'high',
                'message': f'⚠️ KIDNEY CONCERN: High sodium ({sodium}mg) may strain kidneys',
                'medical_fact': 'Limit sodium intake to <2300 mg/day; lower for hypertension. Excess sodium increases urinary calcium excretion, raises stone risk',
                'recommendation': 'Choose low-sodium alternatives to reduce kidney workload'
            })
        elif sodium is not None and sodium < 50:
            positives.append({
                'condition': 'kidney_issues',
                'message': f'✅ KIDNEY-FRIENDLY: Low sodium ({sodium}mg) reduces kidney strain',
                'medical_fact': 'Fresh foods, sodium-free/low-sodium labeled foods recommended for kidney health',
                'benefit': 'Reduces fluid retention and blood pressure strain on kidneys'
            })
        
        if protein is not None and protein > 20:
            warnings.append({
                'condition': 'kidney_issues',
                'severity': 'medium',
                'message': f'⚠️ PROTEIN CONCERN: High protein ({protein}g) may increase kidney workload',
                'medical_fact': 'Too much animal protein raises calcium, uric acid, lowers urine pH/citrate; substitute legumes, nuts for some protein',
                'recommendation': 'Moderate protein intake recommended for kidney health'
            })
        
        oxalate_keywords = ['spinach', 'rhubarb', 'beets', 'nuts', 'wheat bran', 'chocolate']
        if any(keyword in ingredients for keyword in oxalate_keywords):
            warnings.append({
                'condition': 'kidney_issues',
                'severity': 'medium',
                'message': '⚠️ OXALATE CONTENT: Contains foods that may contribute to kidney stones',
                'medical_fact': 'High oxalate foods raise urinary oxalate; limit if prone to calcium oxalate stones',
                'recommendation': 'Consume in moderation and ensure adequate hydration'
            })
        
        sources.extend([
            'https://www.kidney.org/kidney-topics/kidney-stone-diet-plan-and-prevention',
            'https://www.niddk.nih.gov/health-information/urologic-diseases/kidney-stones/eating-diet-nutrition'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }

    def _analyze_thyroid_comprehensive(self, ingredients):
        """COMPLETE thyroid analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        iodine_keywords = ['iodized salt', 'seafood', 'fish', 'shellfish', 'dairy', 'eggs']
        if any(keyword in ingredients for keyword in iodine_keywords):
            positives.append({
                'condition': 'thyroid_hypo',
                'message': '✅ THYROID SUPPORT: Contains iodine sources beneficial for thyroid function',
                'medical_fact': 'Iodine from iodized salt, seafood, dairy, eggs supports thyroid hormone synthesis. RDA: ~150 µg/day adults',
                'benefit': 'Supports thyroid hormone production and metabolic function'
            })
        
        if 'brazil nuts' in ingredients or 'tuna' in ingredients or 'sardines' in ingredients:
            positives.append({
                'condition': 'thyroid_hypo',
                'message': '✅ THYROID HEALTH: Contains selenium that supports antioxidant defense',
                'medical_fact': 'Selenium from Brazil nuts, tuna, sardines, eggs, legumes supports antioxidant defense & thyroid hormone synthesis',
                'benefit': 'Protects thyroid tissue from oxidative damage'
            })
        
        goitrogen_keywords = ['raw broccoli', 'raw cabbage', 'raw kale', 'raw cauliflower']
        if any(keyword in ingredients for keyword in goitrogen_keywords):
            warnings.append({
                'condition': 'thyroid_hypo',
                'severity': 'low',
                'message': '⚠️ GOITROGEN CONTENT: Contains raw cruciferous vegetables that may affect thyroid',
                'medical_fact': 'Excessive raw cruciferous intake may reduce thyroid hormone synthesis. Cooking deactivates goitrogens',
                'recommendation': 'Consume cooked rather than raw, and in moderation'
            })
        
        sources.extend([
            'https://www.healthline.com/nutrition/hypothyroidism-diet',
            'https://health.clevelandclinic.org/hypothyroidism-diet'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }

    def _analyze_liver_comprehensive(self, sugar, saturated_fat, ingredients):
        """COMPLETE fatty liver analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        if sugar is not None and sugar > 10:
            warnings.append({
                'condition': 'liver_fatty',
                'severity': 'high',
                'message': f'⚠️ LIVER CONCERN: High sugar ({sugar}g) promotes liver fat accumulation',
                'medical_fact': 'High intake (>60% calories), refined carbs, sugary drinks, fructose-rich foods promote hepatic lipid storage. Fructose metabolized directly by liver',
                'recommendation': 'Limit sugar intake to support liver health'
            })
        
        if 'olive oil' in ingredients or 'avocado' in ingredients or 'nuts' in ingredients:
            positives.append({
                'condition': 'liver_fatty',
                'message': '✅ LIVER-HEALTHY FATS: Contains unsaturated fats that reduce liver inflammation',
                'medical_fact': 'Emphasize MUFAs (olive oil, nuts, avocados), PUFAs (omega-3 fatty acids from fish oil, flax seeds). MUFAs improve lipid profile, PUFAs reduce liver fat and inflammation',
                'benefit': 'Reduces hepatic fat accumulation and inflammation'
            })
        
        if 'processed' in ingredients or 'fast food' in ingredients:
            warnings.append({
                'condition': 'liver_fatty',
                'severity': 'medium',
                'message': '⚠️ LIVER STRESS: Processed foods may contain harmful additives',
                'medical_fact': 'Avoid monosodium glutamate (MSG) and processed foods. MSG associated with increased fatty acids, triglycerides, and inflammation in liver',
                'recommendation': 'Choose whole, unprocessed foods for liver health'
            })
        
        sources.extend([
            'https://www.niddk.nih.gov/health-information/liver-disease/nafld-nash',
            'https://www.espen.org/files/ESPEN-Guidelines/ESPEN_practical_guideline_Clinical_nutrition_in_liver_disease.pdf'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }

    def _analyze_osteoporosis_comprehensive(self, nutrients, ingredients):
        """COMPLETE osteoporosis analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        if 'calcium' in ingredients or 'dairy' in ingredients or 'fortified' in ingredients:
            positives.append({
                'condition': 'osteoporosis',
                'message': '✅ BONE HEALTH: Contains calcium sources essential for bone mineralization',
                'medical_fact': 'Calcium essential for bone mineralization; intake 1000–1300 mg/day recommended. Found in dairy, calcium-set tofu, leafy greens',
                'benefit': 'Supports bone density and reduces fracture risk'
            })
        
        if 'vitamin d' in ingredients or 'fortified' in ingredients:
            positives.append({
                'condition': 'osteoporosis',
                'message': '✅ BONE SUPPORT: Contains vitamin D for calcium absorption',
                'medical_fact': 'Vitamin D required for calcium absorption and muscle function; 600-800 IU/day recommended',
                'benefit': 'Enhances calcium utilization and bone strength'
            })
        
        if 'protein' in ingredients:
            positives.append({
                'condition': 'osteoporosis',
                'message': '✅ BONE MATRIX SUPPORT: Contains protein essential for bone formation',
                'medical_fact': 'Protein essential for bone matrix formation and maintenance; 1.0-1.2 g/kg/day recommended. Higher protein intake linked to increased BMD',
                'benefit': 'Supports bone tissue repair and maintenance'
            })
        
        sources.extend([
            'https://www.niams.nih.gov/health-topics/calcium-and-vitamin-d-important-bone-health',
            'https://pmc.ncbi.nlm.nih.gov/articles/PMC9944083/'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }

    def _analyze_gout_comprehensive(self, ingredients, nutrients):
        """COMPLETE gout analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        purine_keywords = ['red meat', 'organ meats', 'liver', 'kidney', 'sweetbreads', 'shellfish', 'anchovies', 'sardines']
        if any(keyword in ingredients for keyword in purine_keywords):
            warnings.append({
                'condition': 'gout',
                'severity': 'high',
                'message': '❌ GOUT RISK: Contains high-purine foods that increase uric acid',
                'medical_fact': 'Red meats, organ meats, certain seafood can raise uric acid. Animal and seafood high in purine can raise uric acid',
                'recommendation': 'Limit or avoid to prevent gout flares'
            })
        
        if 'low-fat dairy' in ingredients or 'skim milk' in ingredients or 'yogurt' in ingredients:
            positives.append({
                'condition': 'gout',
                'message': '✅ GOUT MANAGEMENT: Contains low-fat dairy that may reduce uric acid',
                'medical_fact': 'Low-fat and nonfat dairy are uricosuric and anti-inflammatory; may reduce uric acid and frequency of gout attacks',
                'benefit': 'Helps excrete uric acid and reduce inflammation'
            })
        
        if 'legumes' in ingredients or 'tofu' in ingredients or 'plant protein' in ingredients:
            positives.append({
                'condition': 'gout',
                'message': '✅ GOUT-FRIENDLY PROTEIN: Plant-based proteins do not raise gout risk',
                'medical_fact': 'Plant protein does not raise gout risk; contains anti-inflammatory flavonoids and fiber aiding gut microbiota',
                'benefit': 'Provides protein without increasing uric acid levels'
            })
        
        sources.extend([
            'https://www.arthritis.org/health-wellness/healthy-living/nutrition/healthy-eating/which-foods-are-safe-for-gout',
            'https://www.kidney.org/news-stories/what-to-eat-and-avoid-if-you-have-gout'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }

    def _analyze_ibs_comprehensive(self, fiber, ingredients):
        """COMPLETE IBS analysis using ALL your provided rules EXACTLY"""
        warnings, positives, sources = [], [], []
        
        soluble_fiber_keywords = ['oats', 'psyllium', 'linseeds', 'carrot', 'peeled potatoes']
        if any(keyword in ingredients for keyword in soluble_fiber_keywords):
            positives.append({
                'condition': 'ibs',
                'message': '✅ IBS-FRIENDLY FIBER: Contains soluble fiber that improves symptoms',
                'medical_fact': 'Soluble fiber - oats, psyllium, linseeds, carrot, peeled potatoes improves constipation and overall IBS symptoms',
                'benefit': 'Gentle on digestive system and helps regulate bowel function'
            })
        
        high_fodmap_keywords = ['onion', 'garlic', 'cabbage', 'cauliflower', 'asparagus', 'artichokes']
        if any(keyword in ingredients for keyword in high_fodmap_keywords):
            warnings.append({
                'condition': 'ibs',
                'severity': 'medium',
                'message': '⚠️ IBS TRIGGER: Contains high FODMAP ingredients that may cause symptoms',
                'medical_fact': 'High FODMAP vegetables increase gut fermentation and water retention causing bloating, gas',
                'recommendation': 'May cause discomfort in sensitive individuals'
            })
        
        if 'milk' in ingredients or 'cream' in ingredients or 'soft cheese' in ingredients:
            warnings.append({
                'condition': 'ibs',
                'severity': 'medium',
                'message': '⚠️ LACTOSE CONTENT: May trigger IBS symptoms in lactose-sensitive individuals',
                'medical_fact': 'Lactose intolerance common in IBS; regular milk, soft cheeses, ice cream may exacerbate symptoms',
                'recommendation': 'Choose lactose-free alternatives if sensitive'
            })
        
        sources.extend([
            'https://www.monashfodmap.com/about-fodmap-and-ibs/',
            'https://www.nhs.uk/conditions/irritable-bowel-syndrome-ibs/diet-lifestyle-and-medicines/'
        ])
        
        return {
            'reasons': [],
            'warnings': warnings,
            'positives': positives,
            'sources': sources
        }

    def _generate_medical_recommendation(self, warnings, positives, allergen_warnings, preference_warnings):
        """Generate overall medical recommendation based on analysis - UPDATED LOGIC"""
        critical_warnings = [w for w in warnings if w.get('severity') == 'critical']
        high_warnings = [w for w in warnings if w.get('severity') == 'high']
        medium_warnings = [w for w in warnings if w.get('severity') == 'medium']
    
        if allergen_warnings:
            return 'Not Recommended - Contains Allergens'
    
        critical_pref_warnings = [w for w in preference_warnings if w.get('severity') == 'critical']
        if critical_pref_warnings:
            return 'Not Recommended - Violates Dietary Preferences'

        if critical_warnings:
            return 'Not Recommended - Critical Health Risks'
        elif high_warnings:
            return 'Use With Caution - Significant Concerns'
        elif medium_warnings and positives:
            return 'Moderately Suitable - Some Benefits'
        elif medium_warnings:
            return 'Use With Caution - Some Concerns'
        elif positives and not warnings:
            return 'Highly Recommended - Excellent Choice'
        elif positives:
            return 'Moderately Suitable - Some Benefits'
        else:
            return 'Neutral - Limited Information'
    
    def _extract_all_nutrients(self, nutrition):
        """Extract nutrient values from nutrition data - FIXED LOGIC"""
        nutrients = {}
        
        print(f"🔍 NUTRITION DATA RECEIVED: {nutrition}")
        
        mapping = {
            'sugar': ['sugar', 'sugars', 'total sugar', 'total sugars'],
            'fiber': ['fiber', 'dietary fiber', 'fibre', 'dietary fibre'],
            'sodium': ['sodium', 'salt', 'na'],
            'saturated_fat': ['saturated', 'saturated fat', 'sat fat', 'sat. fat'],
            'protein': ['protein'],
            'carbohydrate': ['carbohydrate', 'carb', 'carbs', 'total carbohydrate', 'total carbohydrates'],
            'fat': ['fat', 'total fat'],
            'energy': ['energy', 'calorie', 'calories', 'kcal']
        }
        
        for nutrient_key, possible_names in mapping.items():
            nutrients[nutrient_key] = self._find_nutrient_value(nutrition, possible_names)
            
        print(f"🔍 EXTRACTED NUTRIENTS: {nutrients}")
            
        return nutrients
    
    def _find_nutrient_value(self, nutrition, possible_names):
        """Find nutrient value by multiple possible names - FIXED LOGIC"""
        for key, value in nutrition.items():
            key_lower = key.lower()
            for name in possible_names:
                if name in key_lower:
                    if isinstance(value, dict):
                        val_str = value.get('per_100g', '') or value.get('per_serving', '')
                    else:
                        val_str = str(value)
                    
                    match = re.search(r'(\d+\.?\d*)\s*(?:g|mg|kcal)?', str(val_str).lower())
                    if match:
                        extracted_value = float(match.group(1))
                        print(f"🔍 Found {name}: {extracted_value} from '{val_str}'")
                        return extracted_value
                    
                    if val_str and val_str.strip():
                        number_match = re.search(r'(\d+\.?\d*)', str(val_str))
                        if number_match:
                            extracted_value = float(number_match.group(1))
                            print(f"🔍 Found {name} (fallback): {extracted_value} from '{val_str}'")
                            return extracted_value
        
        print(f"🔍 No value found for {possible_names}")
        return None