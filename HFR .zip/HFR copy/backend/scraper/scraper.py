import requests
from bs4 import BeautifulSoup
import re
import time
import random

def safe_text(tag):
    return tag.get_text(strip=True) if tag else ""

def extract_section_text(soup, heading_text):
    result = ""
    accordions = soup.find_all("div", class_="accordion_core-accordion-item__b_fD_")
    for accordion in accordions:
        heading = accordion.find("h3", class_="accordion_core-accordion-heading__4kxZ4")
        content = accordion.find("div", class_="accordion_core-accordion-content__mE_sq")
        if heading and content:
            if heading_text in heading.get_text():
                result = content.get_text(separator=" ", strip=True)
                break
    return result

def extract_nutrition_dict(soup):
    nutrition = {}
    accordions = soup.find_all("div", class_="accordion_core-accordion-item__b_fD_")
    for accordion in accordions:
        heading = accordion.find("h3", class_="accordion_core-accordion-heading__4kxZ4")
        if heading and "Nutrition information" in heading.get_text():
            content = accordion.find("div", class_="accordion_core-accordion-content__mE_sq")
            if content:
                panel = content.find("div", class_="nutritional-info_component_nutritional-info-panel__jgVXH")
                if panel:
                    nutrition_rows = panel.find_all("ul", class_="nutritional-info_component_nutrition-row__IYE_S")
                    for row in nutrition_rows:
                        items = row.find_all("li")
                        if len(items) >= 3:
                            label = safe_text(items[0])
                            per_serv = safe_text(items[1])
                            per_100g = safe_text(items[2])
                            nutrition[label] = {
                                "per_serving": per_serv,
                                "per_100g": per_100g
                            }
    return nutrition

def extract_product_info(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    try:
        print(f"🌐 Fetching URL: {url}")
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        time.sleep(random.uniform(2,4))  
        
        soup = BeautifulSoup(response.text, 'html.parser')

        result = {
            "url": url,
            "product_name": "",
            "product_details": "",
            "ingredients": "",
            "allergens": "",
            "nutrition": {}
        }

        name_tag = soup.find("h1")
        result["product_name"] = safe_text(name_tag)
        print(f"📛 Product name: {result['product_name']}")

        result["product_details"] = extract_section_text(soup, "Product details")
        result["ingredients"] = extract_section_text(soup, "Ingredients")
        result["allergens"] = extract_section_text(soup, "Allergens")
        result["nutrition"] = extract_nutrition_dict(soup)

        print(f"✅ Successfully extracted:")
        print(f"   - Ingredients: {'Yes' if result['ingredients'] else 'No'}")
        print(f"   - Allergens: {'Yes' if result['allergens'] else 'No'}")
        print(f"   - Nutrition items: {len(result['nutrition'])}")
        if result['nutrition']:
            for nutrient, values in result['nutrition'].items():
                print(f"     {nutrient}: {values}")

        return result
        
    except Exception as e:
        print(f"❌ Error extracting from {url}: {str(e)}")
        return {
            "url": url,
            "product_name": f"Error: {str(e)}",
            "product_details": "",
            "ingredients": "",
            "allergens": "",
            "nutrition": {}
        }

def extract_product_info_enhanced(url):
    """
    Enhanced version that handles multiple store formats
    Falls back to the main function
    """
    return extract_product_info(url)

def test_scraper_with_real_url():
    """Test with a real Walmart product URL"""
    test_urls = [
        "https://www.woolworths.com.au/shop/productdetails/84628/arnott-s-tim-tam-original-family-pack-chocolate-biscuits"

    ]
    
    for url in test_urls:
        print(f"\n🧪 Testing URL: {url}")
        result = extract_product_info(url)
        print(f"📊 Result: {result['product_name']}")
        print(f"📈 Nutrition data: {len(result['nutrition'])} items")
        
    return "Test completed"

if __name__ == "__main__":
    test_scraper_with_real_url()