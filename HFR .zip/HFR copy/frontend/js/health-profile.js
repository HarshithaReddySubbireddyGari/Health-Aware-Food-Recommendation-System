
document.addEventListener('DOMContentLoaded', function() {
    const healthForm = document.getElementById('health-profile-form');
    
    healthForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const submitBtn = this.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span>Medical Analysis...</span>';
        
        try {
            const healthProfile = {
                conditions: {},
                restrictions: {},
                allergies: []
            };
            
            document.querySelectorAll('input[name="conditions"]:checked').forEach(checkbox => {
                healthProfile.conditions[checkbox.value] = true;
            });
            
            document.querySelectorAll('input[name="restrictions"]:checked').forEach(checkbox => {
                healthProfile.restrictions[checkbox.value] = true;
            });
            
            const allergiesInput = document.getElementById('allergies');
            if (allergiesInput && allergiesInput.value.trim()) {
                healthProfile.allergies = allergiesInput.value.split(',').map(a => a.trim()).filter(a => a);
            }
            
            console.log('🏥 Medical Health Profile:', healthProfile);
            
            const productsData = JSON.parse(localStorage.getItem('productsData') || '[]');
            
            if (productsData.length === 0) {
                alert('No products to analyze. Please go back and upload products first.');
                return;
            }
            
            console.log('📦 Products for medical analysis:', productsData.length);
            
            submitBtn.innerHTML = '<span>Running Medical Analysis...</span>';
            
            const response = await fetch('/api/analyze-products', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    products: productsData,
                    health_profile: healthProfile
                })
            });
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            console.log('🎯 Medical Analysis result:', result);
            
            localStorage.setItem('analysisResults', JSON.stringify(result));
            localStorage.setItem('healthProfile', JSON.stringify(healthProfile));
            window.location.href = 'recommendations.html';
            
        } catch (error) {
            console.error('❌ Error in medical analysis:', error);
            alert('Medical analysis failed: ' + error.message);
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<span>Generate Recommendations</span><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>';
        }
    });

    const checkboxes = document.querySelectorAll('.checkbox-item');
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('click', function(e) {
            const input = this.querySelector('input');
            input.checked = !input.checked;
        });
    });
});