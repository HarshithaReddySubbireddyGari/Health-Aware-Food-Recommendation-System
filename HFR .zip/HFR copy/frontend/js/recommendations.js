document.addEventListener('DOMContentLoaded', function() {
    const recommendationsApp = new MedicalRecommendationsApp();
    recommendationsApp.init();
});

class MedicalRecommendationsApp {
    constructor() {
        this.rankedProducts = [];
        this.healthProfile = {};
        this.allSources = new Set();
    }

    async init() {
        await this.loadData();
        this.renderHealthProfile();
        this.renderMedicalSourcesSummary();
        this.renderMedicalRecommendations();
        this.addMedicalStyles();
        this.logProductScores();
    }

    async loadData() {
        try {
            const results = JSON.parse(localStorage.getItem('analysisResults'));
            const healthProfile = JSON.parse(localStorage.getItem('healthProfile'));
            
            if (!results || !results.ranked_products) {
                throw new Error('No analysis results found. Please complete the previous steps.');
            }

            this.rankedProducts = results.ranked_products;
            this.healthProfile = healthProfile || {};

            this.rankedProducts.forEach(product => {
                if (product.health_analysis?.sources) {
                    product.health_analysis.sources.forEach(source => {
                        this.allSources.add(source);
                    });
                }
            });

            console.log('📊 Loaded medical analysis:', this.rankedProducts.length, 'products');

        } catch (error) {
            this.showError('Failed to load recommendations: ' + error.message);
            console.error('Error loading data:', error);
            
            setTimeout(() => {
                window.location.href = 'upload.html';
            }, 3000);
        }
    }

    renderHealthProfile() {
        const container = document.getElementById('health-profile-display');
        if (!container) return;

        let profileHTML = '<h3>Your Health Profile Analysis</h3><div class="profile-tags">';
        
        if (this.healthProfile.conditions && Object.keys(this.healthProfile.conditions).length > 0) {
            profileHTML += '<div class="profile-section"><strong>Medical Conditions:</strong><div class="tag-group">';
            Object.keys(this.healthProfile.conditions).forEach(condition => {
                if (this.healthProfile.conditions[condition]) {
                    profileHTML += `<span class="health-tag condition">${this.getConditionDisplayName(condition)}</span>`;
                }
            });
            profileHTML += '</div></div>';
        }

        if (this.healthProfile.restrictions && Object.keys(this.healthProfile.restrictions).length > 0) {
            profileHTML += '<div class="profile-section"><strong>Dietary Restrictions:</strong><div class="tag-group">';
            Object.keys(this.healthProfile.restrictions).forEach(restriction => {
                if (this.healthProfile.restrictions[restriction]) {
                    profileHTML += `<span class="health-tag restriction">${this.getRestrictionDisplayName(restriction)}</span>`;
                }
            });
            profileHTML += '</div></div>';
        }

        if (this.healthProfile.allergies && this.healthProfile.allergies.length > 0) {
            profileHTML += '<div class="profile-section"><strong>Allergens:</strong><div class="tag-group">';
            this.healthProfile.allergies.forEach(allergen => {
                profileHTML += `<span class="health-tag allergen">${this.getAllergenDisplayName(allergen)}</span>`;
            });
            profileHTML += '</div></div>';
        }

        profileHTML += '</div>';
        container.innerHTML = profileHTML;
    }

    renderMedicalSourcesSummary() {
        const container = document.getElementById('medical-sources-summary');
        if (!container) return;

        const recommendedCount = this.rankedProducts.filter(p => 
            this.isProductRecommended(p)
        ).length;

        const notRecommendedCount = this.rankedProducts.length - recommendedCount;

        let sourcesHTML = `
            <div class="medical-sources-summary">
                <div class="sources-section">
                    <h4>📚 Medical References</h4>
                    <div class="sources-list">
                        ${Array.from(this.allSources).map(source => `
                            <div class="source-item">
                                <a href="${source}" target="_blank" rel="noopener">${this.getSourceDisplayName(source)}</a>
                            </div>
                        `).join('')}
                    </div>
                </div>
                <div class="recommendation-summary">
                    <h4>📋 Recommendation Summary</h4>
                    <div class="summary-stats-simple">
                        <div class="stat-item recommended">
                            <span class="stat-number">${recommendedCount}</span>
                            <span class="stat-label">Recommended</span>
                        </div>
                        <div class="stat-item not-recommended">
                            <span class="stat-number">${notRecommendedCount}</span>
                            <span class="stat-label">Not Recommended</span>
                        </div>
                    </div>
                    <p class="summary-note">Based on evidence-based medical guidelines for your health conditions</p>
                </div>
            </div>
        `;

        container.innerHTML = sourcesHTML;
    }

    renderMedicalRecommendations() {
        const container = document.getElementById('recommendations-container');
        if (!container) return;

        if (this.rankedProducts.length === 0) {
            container.innerHTML = this.getNoProductsHTML();
            return;
        }

        const recommendedProducts = [];
        const notRecommendedProducts = [];

        this.rankedProducts.forEach(product => {
            if (this.isProductRecommended(product)) {
                recommendedProducts.push(product);
            } else {
                notRecommendedProducts.push(product);
            }
        });

        let recommendationsHTML = '';

        if (recommendedProducts.length > 0) {
            recommendationsHTML += '<h3 class="recommendation-category recommended">✅ Recommended Products</h3>';
            recommendationsHTML += recommendedProducts.map(product => 
                this.getMedicalProductCardHTML(product, true)
            ).join('');
        }

        if (notRecommendedProducts.length > 0) {
            recommendationsHTML += '<h3 class="recommendation-category not-recommended">❌ Not Recommended</h3>';
            recommendationsHTML += notRecommendedProducts.map(product => 
                this.getMedicalProductCardHTML(product, false)
            ).join('');
        }

        container.innerHTML = recommendationsHTML;
    }

    isProductRecommended(product) {
        const analysis = product.health_analysis || {};
        const warnings = analysis.medical_warnings || [];
        const preferenceWarnings = analysis.preference_warnings || [];
        const allergenWarnings = analysis.allergen_warnings || [];
        const score = analysis.overall_score || 0;
        
        // STAGE 1: Safety Filter - Immediate Disqualifiers
        const hasCriticalWarnings = warnings.some(w => w.severity === 'critical');
        const hasHighWarnings = warnings.some(w => w.severity === 'high');
        const hasAllergenWarnings = allergenWarnings.length > 0;
        const hasCriticalPrefWarnings = preferenceWarnings.some(w => w.severity === 'critical' || w.severity === 'high');
        
        // If any safety issues found, NOT RECOMMENDED
        if (hasCriticalWarnings || hasHighWarnings || hasAllergenWarnings || hasCriticalPrefWarnings) {
            return false;
        }
        
        // STAGE 2: Quality Filter - Score Threshold
        // Only recommend if score is 50 or higher
        return score >= 50;
    }

    getMedicalProductCardHTML(product, isRecommended) {
        const analysis = product.health_analysis || {};
        const score = analysis.overall_score || 0;
        
        // Determine recommendation reason
        let recommendationReason = '';
        if (isRecommended) {
            if (score >= 50) {
                recommendationReason = `<div class="recommendation-reason">✅ Recommended based on good health score (${score}/100)</div>`;
            } else {
                recommendationReason = `<div class="recommendation-reason">✅ Recommended - No safety concerns detected</div>`;
            }
        }
        
        return `
        <div class="medical-product-card">
            <!-- Product Header -->
            <div class="product-header-medical">
                <div class="product-main-info">
                    <h3 class="product-name">${this.escapeHtml(product.product_name)}</h3>
                    <div class="medical-recommendation-badge ${isRecommended ? 'recommended' : 'not-recommended'}">
                        ${isRecommended ? '✅ Recommended' : '❌ Not Recommended'}
                    </div>
                    <div class="product-score-badge">
                        📊 Score: ${score}/100
                    </div>
                </div>
            </div>

            <!-- Recommendation Reason -->
            ${recommendationReason}

            <!-- Medical Analysis Content -->
            <div class="medical-analysis-content">
                <!-- Allergen Warnings (Highest Priority) -->
                ${analysis.allergen_warnings && analysis.allergen_warnings.length > 0 ? `
                    <div class="analysis-section allergen-warnings">
                        <h4>🚫 ALLERGEN ALERT</h4>
                        <div class="warnings-list">
                            ${analysis.allergen_warnings.map(warning => `
                                <div class="warning-item critical">
                                    <div class="warning-message">${warning.message}</div>
                                    <div class="medical-recommendation"><strong>Safety:</strong> ${warning.recommendation || 'Avoid this product'}</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}

                <!-- Dietary Preference Warnings -->
                ${analysis.preference_warnings && analysis.preference_warnings.length > 0 ? `
                    <div class="analysis-section preference-warnings">
                        <h4>📋 Dietary Preference Issues</h4>
                        <div class="warnings-list">
                            ${analysis.preference_warnings.map(warning => `
                                <div class="warning-item ${warning.severity}">
                                    <div class="warning-message">${warning.message}</div>
                                    <div class="medical-recommendation"><strong>Recommendation:</strong> ${warning.recommendation}</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}

                <!-- Critical Warnings -->
                ${analysis.medical_warnings && analysis.medical_warnings.length > 0 ? `
                    <div class="analysis-section critical-warnings">
                        <h4>🚨 Health Considerations</h4>
                        <div class="warnings-list">
                            ${analysis.medical_warnings.map(warning => `
                                <div class="warning-item ${warning.severity}">
                                    <div class="warning-message">${warning.message}</div>
                                    <div class="medical-fact"><strong>Medical Fact:</strong> ${warning.medical_fact}</div>
                                    <div class="medical-recommendation"><strong>Recommendation:</strong> ${warning.recommendation}</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}

                <!-- Score-Based Recommendation Explanation -->
                ${!isRecommended && score < 50 && !analysis.allergen_warnings?.length && !analysis.medical_warnings?.some(w => w.severity === 'critical' || w.severity === 'high') ? `
                    <div class="analysis-section score-warning">
                        <h4>📊 Quality Assessment</h4>
                        <div class="warnings-list">
                            <div class="warning-item medium">
                                <div class="warning-message">⚠️ Low Health Score: ${score}/100</div>
                                <div class="medical-fact"><strong>Reason:</strong> Product has poor nutritional quality despite no safety concerns</div>
                                <div class="medical-recommendation"><strong>Recommendation:</strong> Consider healthier alternatives with better nutritional profile</div>
                            </div>
                        </div>
                    </div>
                ` : ''}

                <!-- Positive Factors -->
                ${analysis.positive_factors && analysis.positive_factors.length > 0 ? `
                    <div class="analysis-section positive-factors">
                        <h4>💚 Health Benefits</h4>
                        <div class="positives-list">
                            ${analysis.positive_factors.map(positive => `
                                <div class="positive-item">
                                    <div class="positive-message">${positive.message}</div>
                                    <div class="medical-fact"><strong>Medical Benefit:</strong> ${positive.medical_fact}</div>
                                    ${positive.benefit ? `<div class="health-benefit"><strong>Health Impact:</strong> ${positive.benefit}</div>` : ''}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}

                <!-- Product Details -->
                <div class="product-details-grid">
                    <div class="detail-column">
                        <h5>📝 Ingredients Analysis</h5>
                        <div class="detail-content">
                            ${product.ingredients ? 
                                `<p>${this.escapeHtml(product.ingredients)}</p>` : 
                                '<p class="no-data">No ingredients information available</p>'
                            }
                        </div>
                    </div>

                    <div class="detail-column">
                        <h5>📊 Nutrition Facts</h5>
                        <div class="detail-content">
                            ${this.getDetailedNutritionHTML(product.nutrition)}
                        </div>
                    </div>

                    <div class="detail-column">
                        <h5>⚠️ Safety Information</h5>
                        <div class="detail-content">
                            ${product.allergens ? 
                                `<p><strong>Allergens:</strong> ${this.escapeHtml(product.allergens)}</p>` : 
                                '<p class="no-data">No allergen information</p>'
                            }
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        `;
    }

    getDetailedNutritionHTML(nutrition) {
        if (!nutrition || Object.keys(nutrition).length === 0) {
            return '<p class="no-data">No nutrition information available</p>';
        }

        const importantNutrients = {
            'energy': {name: 'Energy', unit: 'kcal'},
            'calorie': {name: 'Calories', unit: 'kcal'},
            'protein': {name: 'Protein', unit: 'g'},
            'fat': {name: 'Total Fat', unit: 'g'},
            'carbohydrate': {name: 'Carbohydrates', unit: 'g'},
            'sugar': {name: 'Sugar', unit: 'g'},
            'sodium': {name: 'Sodium', unit: 'mg'},
            'fiber': {name: 'Dietary Fiber', unit: 'g'},
            'saturated': {name: 'Saturated Fat', unit: 'g'}
        };
        
        let html = '<div class="nutrition-details-medical">';
        
        Object.entries(nutrition).forEach(([nutrient, values]) => {
            const nutrientKey = Object.keys(importantNutrients).find(key => 
                nutrient.toLowerCase().includes(key)
            );
            
            if (nutrientKey) {
                const nutrientInfo = importantNutrients[nutrientKey];
                const per100g = values.per_100g || values.value || 'N/A';
                
                html += `
                    <div class="nutrient-row-medical">
                        <span class="nutrient-name">${nutrientInfo.name}</span>
                        <span class="nutrient-value">${per100g}${nutrientInfo.unit}</span>
                    </div>
                `;
            }
        });

        html += '</div>';
        return html || '<p class="no-data">Limited nutrition data available</p>';
    }

    logProductScores() {
        console.log('🎯 PRODUCT SCORING ANALYSIS');
        console.log('===========================');
        console.log(`Total Products: ${this.rankedProducts.length}`);
        
        this.rankedProducts.forEach((product, index) => {
            const analysis = product.health_analysis || {};
            const score = analysis.overall_score || 0;
            const isRecommended = this.isProductRecommended(product);
            
            console.log(`\n${index + 1}. ${product.product_name}`);
            console.log(`   📊 Overall Score: ${score}/100`);
            console.log(`   🎯 Recommendation: ${isRecommended ? '✅ RECOMMENDED' : '❌ NOT RECOMMENDED'}`);
            
            if (analysis.allergen_warnings && analysis.allergen_warnings.length > 0) {
                console.log(`   🚫 ALLERGEN WARNINGS: ${analysis.allergen_warnings.length}`);
                analysis.allergen_warnings.forEach(warning => {
                    console.log(`      - ${warning.message}`);
                });
            }
            
            if (analysis.preference_warnings && analysis.preference_warnings.length > 0) {
                console.log(`   📋 PREFERENCE WARNINGS: ${analysis.preference_warnings.length}`);
                analysis.preference_warnings.forEach(warning => {
                    console.log(`      - ${warning.message}`);
                });
            }
            
            if (analysis.medical_warnings && analysis.medical_warnings.length > 0) {
                console.log(`   ⚠️  MEDICAL WARNINGS: ${analysis.medical_warnings.length}`);
                const criticalWarnings = analysis.medical_warnings.filter(w => w.severity === 'critical').length;
                const highWarnings = analysis.medical_warnings.filter(w => w.severity === 'high').length;
                const mediumWarnings = analysis.medical_warnings.filter(w => w.severity === 'medium').length;
                const lowWarnings = analysis.medical_warnings.filter(w => w.severity === 'low').length;
                
                console.log(`      Critical: ${criticalWarnings}, High: ${highWarnings}, Medium: ${mediumWarnings}, Low: ${lowWarnings}`);
            }
            
            if (analysis.positive_factors && analysis.positive_factors.length > 0) {
                console.log(`   💚 HEALTH BENEFITS: ${analysis.positive_factors.length}`);
            }

            // Updated recommendation reason logging
            if (!isRecommended) {
                if (analysis.allergen_warnings && analysis.allergen_warnings.length > 0) {
                    console.log(`   ❗ REASON: Contains allergens you specified`);
                } else if (analysis.preference_warnings && analysis.preference_warnings.some(w => w.severity === 'critical' || w.severity === 'high')) {
                    console.log(`   ❗ REASON: Violates dietary preferences`);
                } else if (analysis.medical_warnings && analysis.medical_warnings.some(w => w.severity === 'critical' || w.severity === 'high')) {
                    console.log(`   ❗ REASON: Contains critical/high severity medical warnings`);
                } else if (score < 50) {
                    console.log(`   ❗ REASON: Low health score (${score}/100) - below quality threshold`);
                } else {
                    console.log(`   ❗ REASON: Multiple concerns detected`);
                }
            } else {
                if (score >= 50) {
                    console.log(`   ✅ REASON: No safety concerns + Good health score (${score}/100)`);
                } else {
                    console.log(`   ✅ REASON: No critical issues detected`);
                }
            }
        });
        
        console.log('\n📈 SCORING SUMMARY');
        console.log('=================');
        const recommendedCount = this.rankedProducts.filter(p => this.isProductRecommended(p)).length;
        const notRecommendedCount = this.rankedProducts.length - recommendedCount;
        const avgScore = this.rankedProducts.reduce((sum, product) => {
            return sum + (product.health_analysis?.overall_score || 0);
        }, 0) / this.rankedProducts.length;
        
        // Count products rejected due to low score
        const lowScoreRejects = this.rankedProducts.filter(p => {
            const analysis = p.health_analysis || {};
            const score = analysis.overall_score || 0;
            const hasSafetyIssues = analysis.allergen_warnings?.length > 0 || 
                                  analysis.medical_warnings?.some(w => w.severity === 'critical' || w.severity === 'high') ||
                                  analysis.preference_warnings?.some(w => w.severity === 'critical' || w.severity === 'high');
            return !hasSafetyIssues && score < 50;
        }).length;
        
        console.log(`Average Product Score: ${avgScore.toFixed(1)}/100`);
        console.log(`Recommended Products: ${recommendedCount}`);
        console.log(`Not Recommended: ${notRecommendedCount}`);
        console.log(`Rejected due to low score (safe but poor quality): ${lowScoreRejects}`);
        console.log(`Recommendation Rate: ${((recommendedCount / this.rankedProducts.length) * 100).toFixed(1)}%`);
        
        const productsWithAllergens = this.rankedProducts.filter(p => 
            p.health_analysis?.allergen_warnings && p.health_analysis.allergen_warnings.length > 0
        ).length;
        console.log(`Products with Allergen Warnings: ${productsWithAllergens}`);
        
        const productsWithPrefViolations = this.rankedProducts.filter(p => 
            p.health_analysis?.preference_warnings && p.health_analysis.preference_warnings.length > 0
        ).length;
        console.log(`Products with Preference Violations: ${productsWithPrefViolations}`);
    }

    getSourceDisplayName(source) {
        const sourceMap = {
            'nih.gov': 'National Institutes of Health',
            'mayoclinic.org': 'Mayo Clinic',
            'niddk.nih.gov': 'National Institute of Diabetes and Digestive and Kidney Diseases',
            'heart.org': 'American Heart Association',
            'nhlbi.nih.gov': 'National Heart, Lung, and Blood Institute',
            'hopkinsmedicine.org': 'Johns Hopkins Medicine',
            'kidney.org': 'National Kidney Foundation',
            'arthritis.org': 'Arthritis Foundation',
            'monashfodmap.com': 'Monash University FODMAP',
            'who.int': 'World Health Organization',
            'cdc.gov': 'Centers for Disease Control and Prevention',
            'espen.org': 'European Society for Clinical Nutrition'
        };
        
        for (const [domain, name] of Object.entries(sourceMap)) {
            if (source.includes(domain)) return name;
        }
        return source;
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    getConditionDisplayName(condition) {
        const conditionMap = {
            'diabetes': 'Diabetes',
            'hypertension': 'High Blood Pressure',
            'obesity': 'Weight Management',
            'high_cholesterol': 'High Cholesterol',
            'kidney_issues': 'Kidney Issues',
            'thyroid_hypo': 'Thyroid Disorders',
            'liver_fatty': 'Liver Health',
            'osteoporosis': 'Bone Health',
            'gout': 'Gout',
            'celiac': 'Celiac Disease',
            'lactose_intolerant': 'Lactose Intolerance',
            'ibs': 'Irritable Bowel Syndrome'
        };
        return conditionMap[condition] || condition.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    }

    getRestrictionDisplayName(restriction) {
        const restrictionMap = {
            'gluten_free': 'Gluten-Free',
            'dairy_free': 'Dairy-Free',
            'vegan': 'Vegan',
            'vegetarian': 'Vegetarian',
            'low_sodium': 'Low Sodium',
            'low_sugar': 'Low Sugar',
            'low_fat': 'Low Fat',
            'high_protein': 'High Protein'
        };
        return restrictionMap[restriction] || restriction.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    }

    getAllergenDisplayName(allergen) {
        const allergenMap = {
            'gluten': 'Gluten',
            'dairy': 'Dairy',
            'nuts': 'Nuts',
            'peanuts': 'Peanuts',
            'soy': 'Soy',
            'eggs': 'Eggs',
            'fish': 'Fish',
            'shellfish': 'Shellfish'
        };
        return allergenMap[allergen] || allergen.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    }

    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.innerHTML = `
            <div class="error-content">
                <span class="error-icon">❌</span>
                <span class="error-text">${message}</span>
            </div>
        `;
        document.querySelector('.container').prepend(errorDiv);
    }

    addMedicalStyles() {
        const medicalStyles = `
            /* Medical Sources & Recommendation Summary */
            .medical-sources-summary {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 2rem;
                margin-bottom: 2rem;
                background: white;
                padding: 2rem;
                border-radius: 12px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            }

            .sources-section h4, .recommendation-summary h4 {
                margin: 0 0 1rem 0;
                color: #333;
                font-size: 1.2rem;
                font-weight: 600;
            }

            .sources-list {
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
                max-height: 200px;
                overflow-y: auto;
                padding: 10px;
                background: #f8f9fa;
                border-radius: 6px;
                border: 1px solid #e0e0e0;
            }

            .source-item a {
                color: #1565c0;
                text-decoration: none;
                word-break: break-all;
                font-size: 0.9rem;
            }

            .source-item a:hover {
                text-decoration: underline;
            }

            .summary-stats-simple {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 1rem;
                margin: 1.5rem 0;
            }

            .stat-item {
                text-align: center;
                padding: 1.5rem;
                border-radius: 8px;
                font-weight: 600;
            }

            .stat-item.recommended {
                background: #e8f5e8;
                color: #2e7d32;
                border: 2px solid #4caf50;
            }

            .stat-item.not-recommended {
                background: #ffebee;
                color: #c62828;
                border: 2px solid #f44336;
            }

            .stat-number {
                display: block;
                font-size: 2.5rem;
                font-weight: bold;
                margin-bottom: 0.5rem;
            }

            .stat-label {
                font-size: 1rem;
                opacity: 0.9;
            }

            .summary-note {
                font-size: 0.9rem;
                color: #666;
                text-align: center;
                margin-top: 1rem;
            }

            /* Recommendation Categories */
            .recommendation-category {
                padding: 1rem 1.5rem;
                margin: 2rem 0 1rem 0;
                border-radius: 8px;
                font-weight: 600;
                font-size: 1.3rem;
            }

            .recommendation-category.recommended {
                background: #e8f5e8;
                color: #2e7d32;
                border-left: 6px solid #4caf50;
            }

            .recommendation-category.not-recommended {
                background: #ffebee;
                color: #c62828;
                border-left: 6px solid #f44336;
            }

            /* Medical Product Cards */
            .medical-product-card {
                background: white;
                border-radius: 12px;
                padding: 1.5rem;
                margin-bottom: 2rem;
                box-shadow: 0 4px 15px rgba(0,0,0,0.1);
                border: 1px solid #e0e0e0;
            }

            .product-header-medical {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 1.5rem;
                padding-bottom: 1rem;
                border-bottom: 2px solid #f5f5f5;
            }

            .product-main-info {
                display: flex;
                align-items: center;
                gap: 1rem;
                flex-wrap: wrap;
            }

            .product-name {
                margin: 0;
                color: #2e7d32;
                font-size: 1.4rem;
                font-weight: 600;
            }

            .medical-recommendation-badge {
                padding: 0.75rem 1.5rem;
                border-radius: 25px;
                font-weight: 600;
                font-size: 1rem;
            }

            .medical-recommendation-badge.recommended {
                background: #4caf50;
                color: white;
            }

            .medical-recommendation-badge.not-recommended {
                background: #f44336;
                color: white;
            }

            .product-score-badge {
                padding: 0.5rem 1rem;
                border-radius: 20px;
                background: #2196f3;
                color: white;
                font-weight: 600;
                font-size: 0.9rem;
            }

            .recommendation-reason {
                background: #e8f5e8;
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 1.5rem;
                border-left: 4px solid #4caf50;
                font-weight: 500;
            }

            .analysis-section {
                margin-bottom: 1.5rem;
            }

            .analysis-section h4 {
                margin: 0 0 1rem 0;
                color: #333;
                font-size: 1.1rem;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }

            .allergen-warnings {
                background: #ffebee;
                padding: 1.5rem;
                border-radius: 8px;
                border-left: 4px solid #f44336;
            }

            .preference-warnings {
                background: #fff3e0;
                padding: 1.5rem;
                border-radius: 8px;
                border-left: 4px solid #ff9800;
            }

            .critical-warnings {
                background: #ffebee;
                padding: 1.5rem;
                border-radius: 8px;
                border-left: 4px solid #f44336;
            }

            .score-warning {
                background: #fff3e0;
                padding: 1.5rem;
                border-radius: 8px;
                border-left: 4px solid #ff9800;
            }

            .positive-factors {
                background: #e8f5e8;
                padding: 1.5rem;
                border-radius: 8px;
                border-left: 4px solid #4caf50;
            }

            .warning-item, .positive-item {
                padding: 1rem;
                margin-bottom: 1rem;
                border-radius: 6px;
            }

            .warning-item.critical {
                background: rgba(244, 67, 54, 0.1);
                border-left: 3px solid #f44336;
            }

            .warning-item.high {
                background: rgba(255, 152, 0, 0.1);
                border-left: 3px solid #ff9800;
            }

            .warning-item.medium {
                background: rgba(255, 193, 7, 0.1);
                border-left: 3px solid #ffc107;
            }

            .warning-item.low {
                background: rgba(158, 158, 158, 0.1);
                border-left: 3px solid #9e9e9e;
            }

            .positive-item {
                background: rgba(76, 175, 80, 0.1);
                border-left: 3px solid #4caf50;
            }

            .warning-message, .positive-message {
                font-weight: 600;
                margin-bottom: 0.5rem;
                line-height: 1.4;
            }

            .medical-fact, .health-benefit, .medical-recommendation {
                font-size: 0.9rem;
                margin-bottom: 0.25rem;
                line-height: 1.4;
            }

            .product-details-grid {
                display: grid;
                grid-template-columns: 1fr 1fr 1fr;
                gap: 1.5rem;
                margin: 2rem 0;
            }

            .detail-column {
                background: #f8f9fa;
                padding: 1.25rem;
                border-radius: 8px;
            }

            .detail-column h5 {
                margin: 0 0 1rem 0;
                color: #333;
                font-size: 1rem;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }

            .detail-content {
                max-height: 200px;
                overflow-y: auto;
                padding: 10px;
                background: white;
                border-radius: 6px;
                border: 1px solid #e0e0e0;
            }

            .nutrition-details-medical {
                display: flex;
                flex-direction: column;
                gap: 8px;
            }

            .nutrient-row-medical {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 8px 0;
                border-bottom: 1px solid #f0f0f0;
            }

            .nutrient-row-medical:last-child {
                border-bottom: none;
            }

            .nutrient-name {
                font-weight: 500;
                color: #333;
            }

            .nutrient-value {
                font-weight: 600;
                color: #1976d2;
            }

            .no-data {
                color: #666;
                font-style: italic;
                text-align: center;
                padding: 1rem;
            }

            .profile-tags {
                display: flex;
                flex-direction: column;
                gap: 1rem;
            }

            .profile-section {
                margin-bottom: 1rem;
            }

            .tag-group {
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
                margin-top: 0.5rem;
            }

            .health-tag {
                padding: 0.5rem 1rem;
                border-radius: 20px;
                font-size: 0.9rem;
                font-weight: 500;
            }

            .health-tag.condition {
                background: #e3f2fd;
                color: #1565c0;
                border: 1px solid #90caf9;
            }

            .health-tag.restriction {
                background: #f3e5f5;
                color: #7b1fa2;
                border: 1px solid #ce93d8;
            }

            .health-tag.allergen {
                background: #ffebee;
                color: #c62828;
                border: 1px solid #ef9a9a;
            }

            @media (max-width: 768px) {
                .medical-sources-summary {
                    grid-template-columns: 1fr;
                    gap: 1.5rem;
                }
                
                .summary-stats-simple {
                    grid-template-columns: 1fr;
                }
                
                .product-details-grid {
                    grid-template-columns: 1fr;
                    gap: 1rem;
                }
                
                .product-header-medical {
                    flex-direction: column;
                    gap: 1rem;
                    text-align: center;
                }

                .product-main-info {
                    justify-content: center;
                }
            }
        `;

        const styleSheet = document.createElement('style');
        styleSheet.textContent = medicalStyles;
        document.head.appendChild(styleSheet);
    }

    getNoProductsHTML() {
        return `
            <div class="no-products">
                <h3>No Products Match Your Health Criteria</h3>
                <p>Try uploading different products or adjusting your health profile.</p>
                <button class="btn btn-primary" onclick="window.location.href='upload.html'">
                    Upload New Products
                </button>
            </div>
        `;
    }
}