
document.addEventListener('DOMContentLoaded', function() {
    const optionCards = document.querySelectorAll('.option-card');
    const uploadSections = document.querySelectorAll('.upload-section');
    const processBtn = document.getElementById('process-btn');
    
    optionCards.forEach(card => {
        card.addEventListener('click', function() {
            const option = this.dataset.option;
            
            optionCards.forEach(c => c.classList.remove('active'));
            this.classList.add('active');
            
            uploadSections.forEach(section => section.classList.remove('active'));
            document.getElementById(`${option}-section`).classList.add('active');
            
            updateProcessButton();
        });
    });
    
    const csvUploadArea = document.getElementById('csv-upload-area');
    const csvFileInput = document.getElementById('csv-file');
    const csvPreview = document.getElementById('csv-preview');
    const urlsList = document.getElementById('urls-list');
    
    csvUploadArea.addEventListener('click', () => csvFileInput.click());
    csvUploadArea.addEventListener('dragover', handleDragOver);
    csvUploadArea.addEventListener('drop', handleCsvDrop);
    
    csvFileInput.addEventListener('change', handleCsvFileSelect);
    
    function handleDragOver(e) {
        e.preventDefault();
        csvUploadArea.classList.add('drag-over');
    }
    
    function handleCsvDrop(e) {
        e.preventDefault();
        csvUploadArea.classList.remove('drag-over');
        
        if (e.dataTransfer.files.length) {
            csvFileInput.files = e.dataTransfer.files;
            handleCsvFileSelect();
        }
    }
    
    function handleCsvFileSelect() {
        const file = csvFileInput.files[0];
        if (file && file.name.endsWith('.csv')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const csvContent = e.target.result;
                const urls = parseCsvUrls(csvContent);
                displayUrlsPreview(urls);
            };
            reader.readAsText(file);
            
            csvUploadArea.innerHTML = `
                <div class="upload-icon">✅</div>
                <p>File uploaded: ${file.name}</p>
                <p class="file-types">Processing complete</p>
            `;
        }
    }
    
    function parseCsvUrls(csvContent) {
        const lines = csvContent.split('\n');
        const urls = [];
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            if (line && (line.includes('http') || i === 0)) { 
                urls.push(line);
            }
        }
        return urls;
    }
    
    function displayUrlsPreview(urls) {
        urlsList.innerHTML = '';
        urls.forEach(url => {
            const urlElement = document.createElement('div');
            urlElement.className = 'url-item';
            urlElement.textContent = url;
            urlsList.appendChild(urlElement);
        });
        csvPreview.style.display = 'block';
        updateProcessButton();
    }
    
    const ingredientsUpload = document.getElementById('ingredients-upload');
    const nutritionUpload = document.getElementById('nutrition-upload');
    const imagesPreview = document.getElementById('images-preview');
    const imagesList = document.getElementById('images-list');
    
    let uploadedImages = {
        ingredients: [],
        nutrition: []
    };
    
    setupImageUpload(ingredientsUpload, 'ingredients');
    setupImageUpload(nutritionUpload, 'nutrition');
    
    function setupImageUpload(uploadArea, type) {
        const fileInput = uploadArea.querySelector('input[type="file"]');
        
        uploadArea.addEventListener('click', () => fileInput.click());
        uploadArea.addEventListener('dragover', handleImageDragOver);
        uploadArea.addEventListener('drop', (e) => handleImageDrop(e, type));
        
        fileInput.addEventListener('change', (e) => handleImageSelect(e, type));
    }
    
    function handleImageDragOver(e) {
        e.preventDefault();
        e.currentTarget.classList.add('drag-over');
    }
    
    function handleImageDrop(e, type) {
        e.preventDefault();
        e.currentTarget.classList.remove('drag-over');
        
        if (e.dataTransfer.files.length) {
            handleImageFiles(e.dataTransfer.files, type);
        }
    }
    
    function handleImageSelect(e, type) {
        handleImageFiles(e.target.files, type);
    }
    
    function handleImageFiles(files, type) {
        Array.from(files).forEach(file => {
            if (file.type.startsWith('image/')) {
                uploadedImages[type].push(file);
                displayImagePreview(file, type);
            }
        });
        updateProcessButton();
    }
    
    function displayImagePreview(file, type) {
        const imageItem = document.createElement('div');
        imageItem.className = 'image-item';
        imageItem.innerHTML = `
            <span>${file.name} (${type})</span>
            <button type="button" onclick="removeImage('${file.name}', '${type}')">×</button>
        `;
        imagesList.appendChild(imageItem);
        imagesPreview.style.display = 'block';
    }
    
    function updateProcessButton() {
        const hasUrls = urlsList.children.length > 0;
        const hasImages = Object.values(uploadedImages).some(arr => arr.length > 0);
        
        processBtn.disabled = !(hasUrls || hasImages);
    }
    
    processBtn.addEventListener('click', async function() {
        const activeOption = document.querySelector('.option-card.active').dataset.option;
        
        try {
            processBtn.disabled = true;
            processBtn.innerHTML = '<span>Processing...</span>';
            
            let result;
            if (activeOption === 'urls') {
                result = await processUrls();
            } else {
                result = await processImages();
            }
            
            localStorage.setItem('productsData', JSON.stringify(result.products));
            window.location.href = 'health-profile.html';
            
        } catch (error) {
            alert('Error processing products: ' + error.message);
            console.error('Processing error:', error);
        } finally {
            processBtn.disabled = false;
            processBtn.innerHTML = '<span>Process Products</span><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>';
        }
    });
    
    async function processUrls() {
        const file = csvFileInput.files[0];
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await fetch('/api/process-urls', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('Failed to process URLs');
        }
        
        return await response.json();
    }
    
    async function processImages() {
        const formData = new FormData();
        
        const productGroups = groupImagesByProduct();
        
        if (Object.keys(productGroups).length === 0) {
            throw new Error('No valid product images found. Please upload images with names like "productname_ingredients.jpg" and "productname_nutrients.jpg"');
        }
        
        console.log('📦 Product groups:', productGroups);
        
        Object.entries(productGroups).forEach(([productName, images]) => {
            images.forEach(fileObj => {
                formData.append('images', fileObj.file);
                formData.append('product_names', productName);
            });
        });
        
        console.log('📤 Sending images to server...');
        
        const response = await fetch('/api/process-images', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error('❌ Server response error:', errorText);
            let errorData;
            try {
                errorData = JSON.parse(errorText);
            } catch (e) {
                errorData = { error: errorText || 'Failed to process images' };
            }
            throw new Error(errorData.error || 'Failed to process images');
        }
        
        const result = await response.json();
        console.log('✅ Images processed successfully:', result);
        return result;
    }
    
    function groupImagesByProduct() {
        const productGroups = {};
        
        Object.entries(uploadedImages).forEach(([type, files]) => {
            files.forEach(file => {
                const productName = extractProductNameFromFilename(file.name);
                if (productName) {
                    if (!productGroups[productName]) {
                        productGroups[productName] = [];
                    }
                    const fileWithType = {
                        file: file,
                        type: type,
                        originalName: file.name
                    };
                    productGroups[productName].push(fileWithType);
                }
            });
        });
        
        return productGroups;
    }
    
    function extractProductNameFromFilename(filename) {
        const nameWithoutExt = filename.replace(/\.[^/.]+$/, "");
        
        const productName = nameWithoutExt
            .replace(/_ingredients$/i, '')
            .replace(/_nutrients$/i, '')
            .replace(/_nutrition$/i, '')
            .replace(/_ingredient$/i, '')
            .replace(/_nutrient$/i, '');
        
        const cleanName = productName
            .replace(/_/g, ' ')
            .replace(/\b\w/g, l => l.toUpperCase())
            .trim();
        
        return cleanName || 'Unknown Product';
    }
});

function removeImage(fileName, type) {
    if (window.uploadedImages) {
        window.uploadedImages[type] = window.uploadedImages[type].filter(
            file => file.name !== fileName
        );
        
        const imagesList = document.getElementById('images-list');
        imagesList.innerHTML = '';
        
        Object.entries(window.uploadedImages).forEach(([imgType, files]) => {
            files.forEach(file => {
                displayImagePreview(file, imgType);
            });
        });
        
        updateProcessButton();
    }
}

function displayImagePreview(file, type) {
    const imagesList = document.getElementById('images-list');
    const imageItem = document.createElement('div');
    imageItem.className = 'image-item';
    imageItem.innerHTML = `
        <span>${file.name} (${type})</span>
        <button type="button" onclick="removeImage('${file.name}', '${type}')">×</button>
    `;
    imagesList.appendChild(imageItem);
    
    const imagesPreview = document.getElementById('images-preview');
    imagesPreview.style.display = 'block';
}

function updateProcessButton() {
    const processBtn = document.getElementById('process-btn');
    if (!processBtn) return;
    
    const hasUrls = document.getElementById('urls-list')?.children.length > 0;
    const hasImages = window.uploadedImages && (
        window.uploadedImages.ingredients.length > 0 || 
        window.uploadedImages.nutrition.length > 0
    );
    
    processBtn.disabled = !(hasUrls || hasImages);
}

window.uploadedImages = {
    ingredients: [],
    nutrition: []
};