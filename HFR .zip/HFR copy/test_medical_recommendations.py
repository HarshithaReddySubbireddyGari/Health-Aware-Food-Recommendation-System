import pandas as pd
import json
from datetime import datetime
import re

# =============================================================================
# PRODUCT SCORER CLASS (Include this in the same file)
# =============================================================================

class ProductScorer:
    def __init__(self):
        # Simplified rules for testing
        self.rules = {
            'diabetes': {
                'sugar_threshold': 10,
                'fiber_threshold': 3
            },
            'hypertension': {
                'sodium_threshold': 200
            },
            'high_cholesterol': {
                'saturated_fat_threshold': 3
            },
            'obesity': {
                'sugar_threshold': 10,
                'fiber_threshold': 3
            }
        }
    
    def analyze_product_health(self, product_data, health_profile):
        """Simplified medical analysis for testing"""
        nutrition = product_data.get('nutrition', {})
        ingredients = (product_data.get('ingredients', '') or '').lower()
        allergens = (product_data.get('allergens', '') or '').lower()
        
        analysis_results = {
            'overall_recommendation': 'Neutral - Limited Information',
            'medical_warnings': [],
            'positive_factors': [],
            'allergen_warnings': [],
            'preference_warnings': [],
            'overall_score': 50
        }
        
        # Extract nutrients
        nutrients = self._extract_nutrients(nutrition)
        
        # Check allergens
        analysis_results['allergen_warnings'] = self._check_allergens_simple(allergens, ingredients, health_profile)
        
        # Check medical conditions
        conditions = health_profile.get('conditions', {})
        for condition, is_active in conditions.items():
            if is_active:
                condition_analysis = self._analyze_condition_simple(condition, nutrients, ingredients)
                analysis_results['medical_warnings'].extend(condition_analysis['warnings'])
                analysis_results['positive_factors'].extend(condition_analysis['positives'])
        
        # Generate recommendation
        analysis_results['overall_recommendation'] = self._generate_recommendation_simple(
            analysis_results['medical_warnings'],
            analysis_results['allergen_warnings'],
            analysis_results['positive_factors']
        )
        
        # Calculate score
        analysis_results['overall_score'] = self._calculate_score_simple(
            analysis_results['medical_warnings'],
            analysis_results['allergen_warnings'],
            analysis_results['positive_factors']
        )
        
        return analysis_results
    
    def _extract_nutrients(self, nutrition):
        """Extract nutrient values"""
        nutrients = {}
        
        # Simple extraction logic
        if isinstance(nutrition, dict):
            for key, value in nutrition.items():
                key_lower = key.lower()
                if 'sugar' in key_lower:
                    nutrients['sugar'] = float(value) if isinstance(value, (int, float)) else 0
                elif 'sodium' in key_lower:
                    nutrients['sodium'] = float(value) if isinstance(value, (int, float)) else 0
                elif 'fiber' in key_lower:
                    nutrients['fiber'] = float(value) if isinstance(value, (int, float)) else 0
                elif 'saturated' in key_lower and 'fat' in key_lower:
                    nutrients['saturated_fat'] = float(value) if isinstance(value, (int, float)) else 0
                elif 'protein' in key_lower:
                    nutrients['protein'] = float(value) if isinstance(value, (int, float)) else 0
                elif 'carb' in key_lower:
                    nutrients['carbohydrate'] = float(value) if isinstance(value, (int, float)) else 0
        
        # Ensure all required nutrients have values
        default_nutrients = ['sugar', 'sodium', 'fiber', 'saturated_fat', 'protein', 'carbohydrate']
        for nutrient in default_nutrients:
            if nutrient not in nutrients:
                nutrients[nutrient] = 0
        
        return nutrients
    
    def _check_allergens_simple(self, allergens, ingredients, health_profile):
        """Check for allergens"""
        warnings = []
        user_allergens = health_profile.get('allergies', [])
        
        for allergen in user_allergens:
            allergen_lower = allergen.lower()
            if allergen_lower in allergens or allergen_lower in ingredients:
                warnings.append({
                    'condition': 'allergy',
                    'severity': 'critical',
                    'message': f'Contains {allergen}',
                    'recommendation': 'Avoid'
                })
        
        return warnings
    
    def _analyze_condition_simple(self, condition, nutrients, ingredients):
        """Analyze for specific medical condition"""
        warnings = []
        positives = []
        
        sugar = nutrients.get('sugar', 0)
        sodium = nutrients.get('sodium', 0)
        fiber = nutrients.get('fiber', 0)
        saturated_fat = nutrients.get('saturated_fat', 0)
        
        if condition == 'diabetes':
            if sugar > self.rules['diabetes']['sugar_threshold']:
                warnings.append({
                    'condition': 'diabetes',
                    'severity': 'high',
                    'message': f'High sugar content ({sugar}g)',
                    'recommendation': 'Limit consumption'
                })
            if fiber >= self.rules['diabetes']['fiber_threshold']:
                positives.append({
                    'condition': 'diabetes',
                    'message': f'Good fiber content ({fiber}g)',
                    'benefit': 'Helps blood sugar control'
                })
                
        elif condition == 'hypertension':
            if sodium > self.rules['hypertension']['sodium_threshold']:
                warnings.append({
                    'condition': 'hypertension',
                    'severity': 'high',
                    'message': f'High sodium content ({sodium}mg)',
                    'recommendation': 'Limit consumption'
                })
            elif sodium < 100:
                positives.append({
                    'condition': 'hypertension',
                    'message': f'Low sodium content ({sodium}mg)',
                    'benefit': 'Good for blood pressure'
                })
                
        elif condition == 'high_cholesterol':
            if saturated_fat > self.rules['high_cholesterol']['saturated_fat_threshold']:
                warnings.append({
                    'condition': 'high_cholesterol',
                    'severity': 'high',
                    'message': f'High saturated fat ({saturated_fat}g)',
                    'recommendation': 'Limit consumption'
                })
            if fiber >= 3:
                positives.append({
                    'condition': 'high_cholesterol',
                    'message': f'Good fiber content ({fiber}g)',
                    'benefit': 'Helps cholesterol management'
                })
                
        elif condition == 'obesity':
            if sugar > self.rules['obesity']['sugar_threshold']:
                warnings.append({
                    'condition': 'obesity',
                    'severity': 'medium',
                    'message': f'High sugar content ({sugar}g)',
                    'recommendation': 'Limit for weight management'
                })
            if fiber >= self.rules['obesity']['fiber_threshold']:
                positives.append({
                    'condition': 'obesity',
                    'message': f'Good fiber content ({fiber}g)',
                    'benefit': 'Promotes satiety'
                })
                
        elif condition == 'celiac':
            gluten_keywords = ['wheat', 'barley', 'rye', 'gluten']
            if any(keyword in ingredients for keyword in gluten_keywords):
                warnings.append({
                    'condition': 'celiac',
                    'severity': 'critical',
                    'message': 'Contains gluten',
                    'recommendation': 'Strictly avoid'
                })
                
        elif condition == 'lactose_intolerant':
            dairy_keywords = ['milk', 'cream', 'cheese', 'whey', 'casein']
            if any(keyword in ingredients for keyword in dairy_keywords):
                warnings.append({
                    'condition': 'lactose_intolerant',
                    'severity': 'high',
                    'message': 'Contains dairy',
                    'recommendation': 'Avoid if lactose intolerant'
                })
        
        return {'warnings': warnings, 'positives': positives}
    
    def _generate_recommendation_simple(self, medical_warnings, allergen_warnings, positive_factors):
        """Generate overall recommendation"""
        if allergen_warnings:
            return 'Not Recommended'
        
        critical_warnings = [w for w in medical_warnings if w.get('severity') == 'critical']
        high_warnings = [w for w in medical_warnings if w.get('severity') == 'high']
        medium_warnings = [w for w in medical_warnings if w.get('severity') == 'medium']
        
        if critical_warnings or high_warnings:
            return 'Not Recommended'
        elif medium_warnings and positive_factors:
            return 'Recommended'
        elif medium_warnings:
            return 'Not Recommended'
        elif positive_factors and not medical_warnings:
            return 'Recommended'
        elif positive_factors:
            return 'Recommended'
        else:
            return 'Not Recommended'
    
    def _calculate_score_simple(self, medical_warnings, allergen_warnings, positive_factors):
        """Calculate simple score"""
        score = 50
        
        # Penalties
        if allergen_warnings:
            score -= 30
        for warning in medical_warnings:
            if warning.get('severity') == 'critical':
                score -= 25
            elif warning.get('severity') == 'high':
                score -= 20
            elif warning.get('severity') == 'medium':
                score -= 10
        
        # Bonuses
        score += len(positive_factors) * 5
        
        return max(0, min(100, score))

# =============================================================================
# COMPREHENSIVE TEST DATASET WITH EXPECTED RECOMMENDATIONS
# =============================================================================

def create_comprehensive_test_dataset():
    """Create test dataset with products that should have specific medical recommendations"""
    
    test_products = [
        # 1. DIABETES TEST CASES
        {
            'product_name': 'High Sugar Soda',
            'nutrition': {'sugar': 40, 'carbohydrate': 42, 'fiber': 0, 'energy': 160},
            'ingredients': 'carbonated water, high fructose corn syrup, caramel color, phosphoric acid, natural flavors, caffeine',
            'allergens': '',
            'expected_recommendations': {
                'diabetes': 'Not Recommended',
                'hypertension': 'Not Recommended', 
                'obesity': 'Not Recommended',
                'high_cholesterol': 'Not Recommended',
                'reasoning': 'Very high sugar content, added sugars, no fiber'
            }
        },
        {
            'product_name': 'Whole Grain Oats',
            'nutrition': {'sugar': 1, 'carbohydrate': 12, 'fiber': 8, 'energy': 150},
            'ingredients': 'whole grain oats',
            'allergens': '',
            'expected_recommendations': {
                'diabetes': 'Recommended',
                'hypertension': 'Recommended',
                'obesity': 'Recommended', 
                'high_cholesterol': 'Recommended',
                'reasoning': 'High fiber, low sugar, whole grains'
            }
        },
        {
            'product_name': 'Fruit Yogurt with Added Sugar',
            'nutrition': {'sugar': 18, 'carbohydrate': 20, 'fiber': 0, 'protein': 5, 'energy': 120},
            'ingredients': 'milk, sugar, fruit concentrate, natural flavors, live cultures',
            'allergens': 'milk',
            'expected_recommendations': {
                'diabetes': 'Not Recommended',
                'hypertension': 'Not Recommended',
                'obesity': 'Not Recommended',
                'high_cholesterol': 'Not Recommended',
                'reasoning': 'High added sugar, but contains protein'
            }
        },

        # 2. HYPERTENSION TEST CASES  
        {
            'product_name': 'High Sodium Soup',
            'nutrition': {'sodium': 850, 'sugar': 2, 'fiber': 1, 'energy': 80},
            'ingredients': 'water, vegetables, salt, modified corn starch, monosodium glutamate, flavor enhancers',
            'allergens': '',
            'expected_recommendations': {
                'diabetes': 'Recommended',
                'hypertension': 'Not Recommended',
                'obesity': 'Not Recommended',
                'high_cholesterol': 'Not Recommended',
                'reasoning': 'Extremely high sodium content'
            }
        },
        {
            'product_name': 'Fresh Vegetables',
            'nutrition': {'sodium': 5, 'sugar': 3, 'fiber': 4, 'energy': 25},
            'ingredients': 'fresh mixed vegetables',
            'allergens': '',
            'expected_recommendations': {
                'diabetes': 'Recommended',
                'hypertension': 'Recommended', 
                'obesity': 'Recommended',
                'high_cholesterol': 'Recommended',
                'reasoning': 'Very low sodium, high fiber'
            }
        },

        # 3. HIGH CHOLESTEROL TEST CASES
        {
            'product_name': 'Butter Cookies',
            'nutrition': {'saturated_fat': 12, 'sugar': 15, 'fiber': 1, 'energy': 180},
            'ingredients': 'wheat flour, butter, sugar, eggs, palm oil, artificial flavors',
            'allergens': 'wheat, milk, eggs',
            'expected_recommendations': {
                'diabetes': 'Not Recommended',
                'hypertension': 'Not Recommended',
                'obesity': 'Not Recommended',
                'high_cholesterol': 'Not Recommended',
                'reasoning': 'High saturated fat, high sugar'
            }
        },
        {
            'product_name': 'Avocado',
            'nutrition': {'saturated_fat': 2, 'fiber': 7, 'energy': 160},
            'ingredients': 'avocado',
            'allergens': '',
            'expected_recommendations': {
                'diabetes': 'Recommended',
                'hypertension': 'Recommended',
                'obesity': 'Recommended', 
                'high_cholesterol': 'Recommended',
                'reasoning': 'Healthy fats, high fiber'
            }
        },

        # 4. ALLERGEN TEST CASES
        {
            'product_name': 'Wheat Bread',
            'nutrition': {'sugar': 3, 'fiber': 2, 'sodium': 180, 'energy': 120},
            'ingredients': 'wheat flour, water, yeast, salt',
            'allergens': 'gluten',
            'expected_recommendations': {
                'celiac': 'Not Recommended',
                'diabetes': 'Not Recommended',
                'hypertension': 'Not Recommended',
                'reasoning': 'Contains gluten'
            }
        },
        {
            'product_name': 'Regular Milk',
            'nutrition': {'sugar': 12, 'protein': 8, 'saturated_fat': 5, 'energy': 60},
            'ingredients': 'milk',
            'allergens': 'milk',
            'expected_recommendations': {
                'lactose_intolerant': 'Not Recommended',
                'diabetes': 'Not Recommended',
                'hypertension': 'Recommended',
                'high_cholesterol': 'Not Recommended',
                'reasoning': 'Contains lactose, high natural sugar'
            }
        },

        # 5. OBESITY TEST CASES
        {
            'product_name': 'Fried Potato Chips',
            'nutrition': {'saturated_fat': 8, 'sugar': 1, 'fiber': 1, 'sodium': 170, 'energy': 160},
            'ingredients': 'potatoes, vegetable oil, salt',
            'allergens': '',
            'expected_recommendations': {
                'diabetes': 'Not Recommended',
                'hypertension': 'Not Recommended',
                'obesity': 'Not Recommended',
                'high_cholesterol': 'Not Recommended',
                'reasoning': 'High fat, low nutrition density'
            }
        },
        {
            'product_name': 'Grilled Chicken Breast',
            'nutrition': {'protein': 25, 'saturated_fat': 1, 'sodium': 70, 'energy': 120},
            'ingredients': 'chicken breast',
            'allergens': '',
            'expected_recommendations': {
                'diabetes': 'Recommended',
                'hypertension': 'Recommended',
                'obesity': 'Recommended',
                'high_cholesterol': 'Recommended',
                'reasoning': 'High protein, low fat'
            }
        }
    ]
    
    return test_products

# =============================================================================
# TESTING FRAMEWORK
# =============================================================================

class MedicalRecommendationTester:
    def __init__(self):
        self.scorer = ProductScorer()
        self.test_results = []
        self.metrics = {}
        
    def run_comprehensive_tests(self):
        """Run all medical recommendation tests"""
        test_products = create_comprehensive_test_dataset()
        
        print("🧪 STARTING COMPREHENSIVE MEDICAL RECOMMENDATION TEST")
        print("=" * 70)
        
        for i, product in enumerate(test_products, 1):
            print(f"\n🔍 Testing Product {i}: {product['product_name']}")
            print(f"   Expected: {product['expected_recommendations']}")
            
            product_result = self.test_single_product(product)
            self.test_results.append(product_result)
            
            self.print_product_result(product_result)
        
        # Calculate comprehensive metrics
        self.calculate_detailed_metrics()
        self.generate_test_report()
        
        return self.test_results
    
    def test_single_product(self, product):
        """Test a single product against all relevant health conditions"""
        result = {
            'product_name': product['product_name'],
            'expected': product['expected_recommendations'],
            'actual': {},
            'matches': {},
            'reasoning_analysis': {},
            'score_analysis': {}
        }
        
        # Test each condition that has expected recommendations
        for condition in product['expected_recommendations'].keys():
            if condition in ['reasoning']:  # Skip reasoning key
                continue
                
            # Create health profile for this condition
            health_profile = self.create_health_profile_for_condition(condition)
            
            try:
                # Get analysis from your system
                analysis = self.scorer.analyze_product_health(product, health_profile)
                
                # Extract recommendation
                actual_recommendation = analysis.get('overall_recommendation', 'UNKNOWN')
                score = analysis.get('overall_score', 0)
                
                # Store results
                result['actual'][condition] = actual_recommendation
                result['score_analysis'][condition] = score
                
                # Check if recommendation matches expected
                expected_rec = product['expected_recommendations'][condition]
                match = self.check_recommendation_match(actual_recommendation, expected_rec)
                result['matches'][condition] = match
                
                # Analyze reasoning
                result['reasoning_analysis'][condition] = {
                    'warnings': len(analysis.get('medical_warnings', [])),
                    'positives': len(analysis.get('positive_factors', [])),
                    'allergen_warnings': len(analysis.get('allergen_warnings', [])),
                    'preference_warnings': len(analysis.get('preference_warnings', []))
                }
                
            except Exception as e:
                print(f"   ❌ Error testing {condition}: {str(e)}")
                result['actual'][condition] = f"ERROR: {str(e)}"
                result['matches'][condition] = False
        
        return result
    
    def create_health_profile_for_condition(self, condition):
        """Create appropriate health profile for testing specific condition"""
        profile = {
            'conditions': {},
            'restrictions': {},
            'allergies': []
        }
        
        # Map conditions to profile
        if condition == 'diabetes':
            profile['conditions']['diabetes'] = True
        elif condition == 'hypertension':
            profile['conditions']['hypertension'] = True
        elif condition == 'high_cholesterol':
            profile['conditions']['high_cholesterol'] = True
        elif condition == 'obesity':
            profile['conditions']['obesity'] = True
        elif condition == 'celiac':
            profile['conditions']['celiac'] = True
            profile['allergies'] = ['gluten']
        elif condition == 'lactose_intolerant':
            profile['conditions']['lactose_intolerant'] = True
            profile['allergies'] = ['milk']
        
        return profile
    
    def check_recommendation_match(self, actual, expected):
        """Check if actual recommendation matches expected"""
        # Normalize recommendations for comparison
        actual_norm = self.normalize_recommendation(actual)
        expected_norm = self.normalize_recommendation(expected)
        
        return actual_norm == expected_norm
    
    def normalize_recommendation(self, recommendation):
        """Normalize recommendation text for comparison"""
        if not recommendation:
            return 'UNKNOWN'
        
        rec_lower = recommendation.lower()
        
        if 'not recommended' in rec_lower or 'avoid' in rec_lower or 'strictly avoid' in rec_lower:
            return 'Not Recommended'
        elif 'recommended' in rec_lower or 'excellent' in rec_lower or 'good choice' in rec_lower:
            return 'Recommended'
        else:
            return 'UNKNOWN'
    
    def print_product_result(self, result):
        """Print detailed results for a single product"""
        product_name = result['product_name']
        matches = result['matches']
        
        total_tests = len(matches)
        correct_tests = sum(matches.values())
        accuracy = (correct_tests / total_tests) * 100 if total_tests > 0 else 0
        
        print(f"   📊 Results: {correct_tests}/{total_tests} correct ({accuracy:.1f}%)")
        
        for condition, match in matches.items():
            status = "✅" if match else "❌"
            expected = result['expected'][condition]
            actual = result['actual'][condition]
            score = result['score_analysis'].get(condition, 'N/A')
            
            print(f"      {condition}: {status} Expected {expected}, Got {actual} (Score: {score})")
    
    def calculate_detailed_metrics(self):
        """Calculate precision, recall, accuracy for each health condition"""
        conditions = ['diabetes', 'hypertension', 'high_cholesterol', 'obesity', 'celiac', 'lactose_intolerant']
        self.metrics = {}
        
        print("\n📊 DETAILED ACCURACY METRICS BY HEALTH CONDITION")
        print("=" * 70)
        
        for condition in conditions:
            condition_results = self.get_condition_results(condition)
            
            if not condition_results:
                continue
            
            metrics = self.calculate_condition_metrics(condition_results, condition)
            self.metrics[condition] = metrics
            
            self.print_condition_metrics(condition, metrics)
        
        # Calculate overall metrics
        self.calculate_overall_metrics()
    
    def get_condition_results(self, condition):
        """Get all test results for a specific condition"""
        results = []
        for product_result in self.test_results:
            if condition in product_result['matches']:
                results.append({
                    'product': product_result['product_name'],
                    'expected': product_result['expected'][condition],
                    'actual': product_result['actual'][condition],
                    'match': product_result['matches'][condition],
                    'score': product_result['score_analysis'].get(condition, 0)
                })
        return results
    
    def calculate_condition_metrics(self, condition_results, condition):
        """Calculate metrics for a specific health condition"""
        # Basic accuracy
        correct_predictions = sum(1 for r in condition_results if r['match'])
        total_predictions = len(condition_results)
        accuracy = (correct_predictions / total_predictions) * 100
        
        # For binary classification (Recommended vs Not Recommended)
        true_positives = 0
        false_positives = 0
        true_negatives = 0
        false_negatives = 0
        
        for result in condition_results:
            expected = self.normalize_recommendation(result['expected'])
            actual = self.normalize_recommendation(result['actual'])
            
            if expected == 'Recommended':
                if actual == 'Recommended':
                    true_positives += 1
                else:
                    false_negatives += 1
            else:  # Not Recommended
                if actual == 'Recommended':
                    false_positives += 1
                else:
                    true_negatives += 1
        
        # Calculate precision, recall, F1
        precision = (true_positives / (true_positives + false_positives)) * 100 if (true_positives + false_positives) > 0 else 0
        recall = (true_positives / (true_positives + false_negatives)) * 100 if (true_positives + false_negatives) > 0 else 0
        f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        # Score analysis
        scores = [r['score'] for r in condition_results if isinstance(r['score'], (int, float))]
        avg_score = sum(scores) / len(scores) if scores else 0
        
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1_score,
            'true_positives': true_positives,
            'false_positives': false_positives,
            'true_negatives': true_negatives,
            'false_negatives': false_negatives,
            'total_predictions': total_predictions,
            'correct_predictions': correct_predictions,
            'avg_score': avg_score
        }
    
    def print_condition_metrics(self, condition, metrics):
        """Print metrics for a specific condition"""
        print(f"\n{condition.upper():<20}")
        print(f"  📈 Accuracy:    {metrics['accuracy']:.1f}% ({metrics['correct_predictions']}/{metrics['total_predictions']})")
        print(f"  🎯 Precision:   {metrics['precision']:.1f}%")
        print(f"  🔍 Recall:      {metrics['recall']:.1f}%")
        print(f"  ⚖️  F1 Score:    {metrics['f1_score']:.1f}%")
        print(f"  📊 Avg Score:   {metrics['avg_score']:.1f}/100")
        print(f"  📋 Confusion Matrix:")
        print(f"     True Positives:  {metrics['true_positives']}")
        print(f"     False Positives: {metrics['false_positives']}")
        print(f"     True Negatives:  {metrics['true_negatives']}")
        print(f"     False Negatives: {metrics['false_negatives']}")
    
    def calculate_overall_metrics(self):
        """Calculate overall system metrics"""
        all_matches = []
        for product_result in self.test_results:
            all_matches.extend(product_result['matches'].values())
        
        overall_accuracy = (sum(all_matches) / len(all_matches)) * 100 if all_matches else 0
        
        # Weighted average of condition metrics
        weighted_accuracy = 0
        weighted_f1 = 0
        total_weight = 0
        
        for condition, metrics in self.metrics.items():
            weight = metrics['total_predictions']
            weighted_accuracy += metrics['accuracy'] * weight
            weighted_f1 += metrics['f1_score'] * weight
            total_weight += weight
        
        if total_weight > 0:
            weighted_accuracy /= total_weight
            weighted_f1 /= total_weight
        
        self.metrics['overall'] = {
            'accuracy': overall_accuracy,
            'weighted_accuracy': weighted_accuracy,
            'weighted_f1': weighted_f1,
            'total_tests': len(all_matches),
            'correct_tests': sum(all_matches)
        }
        
        print(f"\n🎯 OVERALL SYSTEM PERFORMANCE")
        print("=" * 50)
        print(f"  📊 Overall Accuracy: {overall_accuracy:.1f}% ({sum(all_matches)}/{len(all_matches)})")
        print(f"  ⚖️  Weighted Accuracy: {weighted_accuracy:.1f}%")
        print(f"  🔥 Weighted F1 Score: {weighted_f1:.1f}%")
    
    def generate_test_report(self):
        """Generate comprehensive test report"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"medical_recommendation_accuracy_report_{timestamp}.xlsx"
        
        # Create detailed results DataFrame
        detailed_data = []
        for result in self.test_results:
            for condition in result['matches'].keys():
                detailed_data.append({
                    'product': result['product_name'],
                    'condition': condition,
                    'expected': result['expected'][condition],
                    'actual': result['actual'][condition],
                    'match': '✅' if result['matches'][condition] else '❌',
                    'score': result['score_analysis'].get(condition, 'N/A'),
                    'reasoning_warnings': result['reasoning_analysis'].get(condition, {}).get('warnings', 0),
                    'reasoning_positives': result['reasoning_analysis'].get(condition, {}).get('positives', 0)
                })
        
        detailed_df = pd.DataFrame(detailed_data)
        
        # Create metrics DataFrame
        metrics_data = []
        for condition, metrics in self.metrics.items():
            if condition != 'overall':
                metrics_data.append({
                    'Condition': condition.upper(),
                    'Accuracy (%)': f"{metrics['accuracy']:.1f}",
                    'Precision (%)': f"{metrics['precision']:.1f}",
                    'Recall (%)': f"{metrics['recall']:.1f}",
                    'F1 Score (%)': f"{metrics['f1_score']:.1f}",
                    'Correct Predictions': f"{metrics['correct_predictions']}/{metrics['total_predictions']}",
                    'Average Score': f"{metrics['avg_score']:.1f}",
                    'True Positives': metrics['true_positives'],
                    'False Positives': metrics['false_positives'],
                    'True Negatives': metrics['true_negatives'],
                    'False Negatives': metrics['false_negatives']
                })
        
        metrics_df = pd.DataFrame(metrics_data)
        
        # Create summary DataFrame
        if 'overall' in self.metrics:
            summary_data = {
                'Metric': [
                    'Test Date',
                    'Total Products Tested',
                    'Total Predictions Made',
                    'Overall Accuracy',
                    'Weighted Accuracy', 
                    'Weighted F1 Score',
                    'Performance Rating'
                ],
                'Value': [
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    len(self.test_results),
                    self.metrics['overall']['total_tests'],
                    f"{self.metrics['overall']['accuracy']:.1f}%",
                    f"{self.metrics['overall']['weighted_accuracy']:.1f}%",
                    f"{self.metrics['overall']['weighted_f1']:.1f}%",
                    self.get_performance_rating(self.metrics['overall']['accuracy'])
                ]
            }
            summary_df = pd.DataFrame(summary_data)
        else:
            summary_df = pd.DataFrame()
        
        # Save to Excel
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            detailed_df.to_excel(writer, sheet_name='Detailed_Results', index=False)
            metrics_df.to_excel(writer, sheet_name='Condition_Metrics', index=False)
            if not summary_df.empty:
                summary_df.to_excel(writer, sheet_name='Test_Summary', index=False)
        
        print(f"\n💾 Comprehensive report saved to: {filename}")
        
        # Performance assessment
        overall_acc = self.metrics.get('overall', {}).get('accuracy', 0)
        print(f"\n📈 PERFORMANCE ASSESSMENT")
        print("=" * 30)
        print(f"Rating: {self.get_performance_rating(overall_acc)}")
        
        return filename
    
    def get_performance_rating(self, accuracy):
        """Get performance rating based on accuracy"""
        if accuracy >= 90:
            return "EXCELLENT 🏆"
        elif accuracy >= 80:
            return "VERY GOOD 👍" 
        elif accuracy >= 70:
            return "GOOD ✅"
        elif accuracy >= 60:
            return "FAIR ⚠️"
        else:
            return "NEEDS IMPROVEMENT ❌"

# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    print("🧬 Starting Medical Recommendation System Accuracy Test")
    print("=" * 70)
    
    try:
        # Initialize tester
        tester = MedicalRecommendationTester()
        
        # Run comprehensive tests
        test_results = tester.run_comprehensive_tests()
        
        print(f"\n🎉 TESTING COMPLETE")
        print("=" * 50)
        print(f"📦 Products Tested: {len(test_results)}")
        print(f"🔍 Conditions Evaluated: {len(tester.metrics) - 1}")
        
        if 'overall' in tester.metrics:
            overall_acc = tester.metrics['overall']['accuracy']
            print(f"📊 Overall Accuracy: {overall_acc:.1f}%")
        
    except Exception as e:
        print(f"❌ Testing failed: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()