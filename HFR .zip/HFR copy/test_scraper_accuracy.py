import pandas as pd
import requests
from bs4 import BeautifulSoup
import re
import time
import random
from datetime import datetime

# =============================================================================
# YOUR SCRAPER FUNCTIONS (copied from your code)
# =============================================================================

def safe_text(tag):
    return tag.get_text(strip=True) if tag else ""

def extract_section_text(soup, heading_text):
    result = ""
    accordions = soup.find_all("div", class_="accordion_core-accordion-item__b_fD_")
    for accordion in accordions:
        heading = accordion.find("h3", class_="accordion_core-accordion-heading__4kxZ4")
        content = accordion.find("div", class_="accordion_core-accordion-content__mE_sq")
        if heading and content:
            if heading_text in heading.get_text():
                result = content.get_text(separator=" ", strip=True)
                break
    return result

def extract_nutrition_dict(soup):
    nutrition = {}
    accordions = soup.find_all("div", class_="accordion_core-accordion-item__b_fD_")
    for accordion in accordions:
        heading = accordion.find("h3", class_="accordion_core-accordion-heading__4kxZ4")
        if heading and "Nutrition information" in heading.get_text():
            content = accordion.find("div", class_="accordion_core-accordion-content__mE_sq")
            if content:
                panel = content.find("div", class_="nutritional-info_component_nutritional-info-panel__jgVXH")
                if panel:
                    nutrition_rows = panel.find_all("ul", class_="nutritional-info_component_nutrition-row__IYE_S")
                    for row in nutrition_rows:
                        items = row.find_all("li")
                        if len(items) >= 3:
                            label = safe_text(items[0])
                            per_serv = safe_text(items[1])
                            per_100g = safe_text(items[2])
                            nutrition[label] = {
                                "per_serving": per_serv,
                                "per_100g": per_100g
                            }
    return nutrition

def extract_product_info(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    try:
        print(f"🌐 Fetching URL: {url}")
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        time.sleep(random.uniform(2,4))  
        
        soup = BeautifulSoup(response.text, 'html.parser')

        result = {
            "url": url,
            "product_name": "",
            "product_details": "",
            "ingredients": "",
            "allergens": "",
            "nutrition": {},
            "success": True,
            "error": None
        }

        name_tag = soup.find("h1")
        result["product_name"] = safe_text(name_tag)
        print(f"📛 Product name: {result['product_name']}")

        result["product_details"] = extract_section_text(soup, "Product details")
        result["ingredients"] = extract_section_text(soup, "Ingredients")
        result["allergens"] = extract_section_text(soup, "Allergens")
        result["nutrition"] = extract_nutrition_dict(soup)

        print(f" Successfully extracted:")
        print(f"   - Ingredients: {'Yes' if result['ingredients'] else 'No'}")
        print(f"   - Allergens: {'Yes' if result['allergens'] else 'No'}")
        print(f"   - Nutrition items: {len(result['nutrition'])}")
        if result['nutrition']:
            for nutrient, values in result['nutrition'].items():
                print(f"     {nutrient}: {values}")

        return result
        
    except Exception as e:
        print(f"❌ Error extracting from {url}: {str(e)}")
        return {
            "url": url,
            "product_name": f"Error: {str(e)}",
            "product_details": "",
            "ingredients": "",
            "allergens": "",
            "nutrition": {},
            "success": False,
            "error": str(e)
        }

# =============================================================================
# UPDATED TEST DATASET WITH YOUR 5 PRODUCT LINKS
# =============================================================================

def create_test_dataset():
    """Create a test dataset with the 5 provided Woolworths product URLs"""
    
    test_products = [
        {
            'url': 'https://www.woolworths.com.au/shop/productdetails/84628/arnott-s-tim-tam-original-family-pack-chocolate-biscuits',
            'expected_name': 'Tim Tam',
            'expected_category': 'Biscuits',
            'expected_has_nutrition': True,
            'expected_has_ingredients': True,
            'expected_has_allergens': True,
            'expected_nutrition_min_items': 5
        },
        {
            'url': 'https://www.woolworths.com.au/shop/productdetails/321220/woolworths-rolled-traditional-oats',
            'expected_name': 'Rolled Oats',
            'expected_category': 'Cereals',
            'expected_has_nutrition': True,
            'expected_has_ingredients': True,
            'expected_has_allergens': True,
            'expected_nutrition_min_items': 4
        },
        {
            'url': 'https://www.woolworths.com.au/shop/productdetails/363951/woolworths-35hr-sourdough-loaf-seeded-seeds-and-grains',
            'expected_name': 'Sourdough Loaf',
            'expected_category': 'Bread',
            'expected_has_nutrition': True,
            'expected_has_ingredients': True,
            'expected_has_allergens': True,
            'expected_nutrition_min_items': 5
        },
        {
            'url': 'https://www.woolworths.com.au/shop/productdetails/815872/woolworths-pecans',
            'expected_name': 'Pecans',
            'expected_category': 'Nuts',
            'expected_has_nutrition': True,
            'expected_has_ingredients': True,
            'expected_has_allergens': True,
            'expected_nutrition_min_items': 4
        },
        {
            'url': 'https://www.woolworths.com.au/shop/productdetails/609563/jordans-crispy-oat-clusters-maple-pecan',
            'expected_name': 'Crispy Oat Clusters',
            'expected_category': 'Cereal',
            'expected_has_nutrition': True,
            'expected_has_ingredients': True,
            'expected_has_allergens': True,
            'expected_nutrition_min_items': 5
        }
    ]
    
    return test_products

# =============================================================================
# ACCURACY TESTING FUNCTIONS
# =============================================================================

def calculate_name_similarity(expected, actual):
    """Calculate similarity between expected and actual product names"""
    if not expected or not actual:
        return 0.0
    
    expected_lower = expected.lower()
    actual_lower = actual.lower()
    
    # Check if expected words are in actual name
    expected_words = expected_lower.split()
    actual_words = actual_lower.split()
    
    if not expected_words:
        return 0.0
    
    matches = sum(1 for word in expected_words if word in actual_lower)
    return matches / len(expected_words)

def test_scraper_accuracy():
    """Test web scraper accuracy with real product URLs"""
    
    test_products = create_test_dataset()
    scraper_results = []
    
    print("🚀 Starting Web Scraper Accuracy Test...")
    print("=" * 60)
    print(f"Testing {len(test_products)} products...")
    print("Products to test:")
    for i, product in enumerate(test_products, 1):
        print(f"  {i}. {product['expected_name']} - {product['url']}")
    
    for i, product in enumerate(test_products, 1):
        url = product['url']
        expected_name = product['expected_name']
        
        print(f"\n🔍 Testing {i}/{len(test_products)}: {product['expected_name']}")
        print(f"   URL: {url}")
        
        # Use the scraper to get actual product data
        scraped_data = extract_product_info(url)
        
        # Calculate name similarity
        name_similarity = calculate_name_similarity(expected_name, scraped_data.get('product_name', ''))
        
        # Check if we got the expected data
        nutrition_ok = len(scraped_data.get('nutrition', {})) >= product['expected_nutrition_min_items']
        ingredients_ok = (bool(scraped_data.get('ingredients', '')) == product['expected_has_ingredients'])
        allergens_ok = (bool(scraped_data.get('allergens', '')) == product['expected_has_allergens'])
        
        result = {
            'product_id': i,
            'url': url,
            'expected_name': expected_name,
            'scraped_name': scraped_data.get('product_name', 'N/A'),
            'name_similarity': name_similarity,
            'name_similarity_percent': f"{name_similarity:.1%}",
            'scraped_success': scraped_data.get('success', False),
            'nutrition_data_found': len(scraped_data.get('nutrition', {})) > 0,
            'nutrition_items_count': len(scraped_data.get('nutrition', {})),
            'nutrition_expected_min': product['expected_nutrition_min_items'],
            'nutrition_test_passed': nutrition_ok,
            'ingredients_found': bool(scraped_data.get('ingredients', '')),
            'ingredients_expected': product['expected_has_ingredients'],
            'ingredients_test_passed': ingredients_ok,
            'allergens_found': bool(scraped_data.get('allergens', '')),
            'allergens_expected': product['expected_has_allergens'],
            'allergens_test_passed': allergens_ok,
            'product_details_found': bool(scraped_data.get('product_details', '')),
            'error_message': scraped_data.get('error', '')
        }
        
        # Print test results
        if scraped_data['success']:
            status = "✅ Success"
            name_status = "✅ Good" if name_similarity >= 0.5 else "⚠️ Partial" if name_similarity >= 0.2 else "❌ Poor"
            print(f"   {status} | Name: {name_status} ({name_similarity:.1%})")
            print(f"    Nutrition: {result['nutrition_items_count']} items (expected min: {product['expected_nutrition_min_items']}) - {'✅ Pass' if nutrition_ok else '❌ Fail'}")
            print(f"    Ingredients: {'✅ Found' if result['ingredients_found'] else '❌ Missing'} - {'✅ Pass' if ingredients_ok else '❌ Fail'}")
            print(f"   Allergens: {'✅ Found' if result['allergens_found'] else '❌ Missing'} - {'✅ Pass' if allergens_ok else '❌ Fail'}")
        else:
            print(f"    Failed: {scraped_data.get('error', 'Unknown error')}")
        
        scraper_results.append(result)
        time.sleep(2)  # Be respectful to the server
    
    return pd.DataFrame(scraper_results)

def analyze_scraper_performance(results_df):
    """Analyze scraper performance metrics"""
    
    print("\n📊 SCRAPER PERFORMANCE ANALYSIS")
    print("=" * 50)
    
    total_tests = len(results_df)
    successful_scrapes = results_df['scraped_success'].sum()
    success_rate = (successful_scrapes / total_tests) * 100
    
    print(f"Total URLs tested: {total_tests}")
    print(f"Successful scrapes: {successful_scrapes}")
    print(f"Success rate: {success_rate:.1f}%")
    
    metrics = {
        'total_tests': total_tests,
        'successful_scrapes': successful_scrapes,
        'success_rate': success_rate,
    }
    
    if successful_scrapes > 0:
        # Calculate various success metrics
        successful_results = results_df[results_df['scraped_success']]
        
        good_name_matches = len(successful_results[successful_results['name_similarity'] >= 0.5])
        nutrition_success_rate = (successful_results['nutrition_test_passed'].sum() / successful_scrapes) * 100
        ingredients_success_rate = (successful_results['ingredients_test_passed'].sum() / successful_scrapes) * 100
        allergens_success_rate = (successful_results['allergens_test_passed'].sum() / successful_scrapes) * 100
        
        avg_nutrition_items = successful_results['nutrition_items_count'].mean()
        avg_name_similarity = successful_results['name_similarity'].mean()
        
        print(f"\n📈 Data Accuracy Rates:")
        print(f"  Good name matches: {good_name_matches}/{successful_scrapes} ({good_name_matches/successful_scrapes*100:.1f}%)")
        print(f"  Average name similarity: {avg_name_similarity:.1%}")
        print(f"  Nutrition test passes: {nutrition_success_rate:.1f}%")
        print(f"  Average nutrition items: {avg_nutrition_items:.1f}")
        print(f"  Ingredients test passes: {ingredients_success_rate:.1f}%")
        print(f"  Allergens test passes: {allergens_success_rate:.1f}%")
        
        # Overall accuracy score
        overall_accuracy = (
            avg_name_similarity * 0.3 +
            (nutrition_success_rate / 100) * 0.3 +
            (ingredients_success_rate / 100) * 0.2 +
            (allergens_success_rate / 100) * 0.2
        ) * 100
        
        print(f"\n🎯 Overall Accuracy Score: {overall_accuracy:.1f}%")
        
        metrics.update({
            'nutrition_success_rate': nutrition_success_rate,
            'ingredients_success_rate': ingredients_success_rate,
            'allergens_success_rate': allergens_success_rate,
            'avg_nutrition_items': avg_nutrition_items,
            'avg_name_similarity': avg_name_similarity,
            'good_name_matches': good_name_matches,
            'overall_accuracy': overall_accuracy
        })
    
    return metrics

def detailed_analysis(scraper_results):
    """Provide detailed analysis of scraping results"""
    print("\n🔍 DETAILED EXTRACTION ANALYSIS")
    print("=" * 50)
    
    successful_results = scraper_results[scraper_results['scraped_success']]
    
    if len(successful_results) == 0:
        print(" No successful scrapes to analyze")
        return
    
    print(f"Analyzing {len(successful_results)} successful scrapes:")
    
    for _, row in successful_results.iterrows():
        print(f"\n📦 Product {row['product_id']}: {row['expected_name']}")
        print(f"   URL: {row['url']}")
        print(f"   Expected Name: '{row['expected_name']}'")
        print(f"   Scraped Name: '{row['scraped_name']}'")
        print(f"   Name Similarity: {row['name_similarity_percent']}")
        print(f"   Nutrition: {row['nutrition_items_count']} items (min expected: {row['nutrition_expected_min']}) - {'✅' if row['nutrition_test_passed'] else '❌'}")
        print(f"   Ingredients: {' Found' if row['ingredients_found'] else ' Missing'} - {'✅' if row['ingredients_test_passed'] else '❌'}")
        print(f"   Allergens: {' Found' if row['allergens_found'] else ' Missing'} - {'✅' if row['allergens_test_passed'] else '❌'}")
        print(f"   Product Details: {' Found' if row['product_details_found'] else ' Missing'}")

def generate_comprehensive_report(results_df, metrics):
    """Generate a comprehensive test report"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"scraper_accuracy_report_{timestamp}.xlsx"
    
    with pd.ExcelWriter(filename, engine='openpyxl') as writer:
        # Save detailed results
        results_df.to_excel(writer, sheet_name='Detailed_Results', index=False)
        
        # Save metrics summary
        if 'overall_accuracy' in metrics:
            metrics_data = {
                'Metric': [
                    'Total URLs Tested',
                    'Successful Scrapes', 
                    'Success Rate',
                    'Overall Accuracy Score',
                    'Average Name Similarity',
                    'Good Name Matches',
                    'Nutrition Test Pass Rate',
                    'Average Nutrition Items',
                    'Ingredients Test Pass Rate',
                    'Allergens Test Pass Rate'
                ],
                'Value': [
                    metrics['total_tests'],
                    metrics['successful_scrapes'],
                    f"{metrics['success_rate']:.1f}%",
                    f"{metrics['overall_accuracy']:.1f}%",
                    f"{metrics['avg_name_similarity']:.1%}",
                    f"{metrics['good_name_matches']}/{metrics['successful_scrapes']}",
                    f"{metrics.get('nutrition_success_rate', 0):.1f}%",
                    f"{metrics.get('avg_nutrition_items', 0):.1f}",
                    f"{metrics.get('ingredients_success_rate', 0):.1f}%",
                    f"{metrics.get('allergens_success_rate', 0):.1f}%"
                ]
            }
        else:
            metrics_data = {
                'Metric': ['Total URLs Tested', 'Successful Scrapes', 'Success Rate'],
                'Value': [metrics['total_tests'], metrics['successful_scrapes'], f"{metrics['success_rate']:.1f}%"]
            }
        
        metrics_df = pd.DataFrame(metrics_data)
        metrics_df.to_excel(writer, sheet_name='Metrics_Summary', index=False)
        
        # Save overall summary
        summary_data = {
            'Test Information': [
                'Test Date',
                'Total Products',
                'Overall Success Rate',
                'Overall Accuracy Score',
                'Report File'
            ],
            'Value': [
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                metrics['total_tests'],
                f"{metrics['success_rate']:.1f}%",
                f"{metrics.get('overall_accuracy', 0):.1f}%" if 'overall_accuracy' in metrics else 'N/A',
                filename
            ]
        }
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_excel(writer, sheet_name='Test_Summary', index=False)
    
    print(f"\nComprehensive report saved to: {filename}")
    return filename

# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    print("🧬 Starting Web Scraper Accuracy Evaluation")
    print("=" * 60)
    print("Testing your scraper with 5 Woolworths products:")
    print("1. Tim Tam Biscuits")
    print("2. Rolled Traditional Oats") 
    print("3. Sourdough Loaf")
    print("4. Pecans")
    print("5. Crispy Oat Clusters")
    print("=" * 60)
    
    try:
        # Test the web scraper
        scraper_results = test_scraper_accuracy()
        
        if len(scraper_results) == 0:
            print(" No scraping results to analyze")
            return
        
        # Analyze scraper performance
        scraper_metrics = analyze_scraper_performance(scraper_results)
        
        # Provide detailed analysis
        detailed_analysis(scraper_results)
        
        # Generate comprehensive report
        report_file = generate_comprehensive_report(scraper_results, scraper_metrics)
        
        # Final assessment
        success_rate = scraper_metrics['success_rate']
        overall_accuracy = scraper_metrics.get('overall_accuracy', 0)
        
        if overall_accuracy >= 80:
            rating = "EXCELLENT"
        elif overall_accuracy >= 60:
            rating = "GOOD "
        elif overall_accuracy >= 40:
            rating = "FAIR ⚠"
        else:
            rating = "POOR "
            
        print(f"\n🎯 FINAL ASSESSMENT")
        print("=" * 30)
        print(f" PERFORMANCE RATING: {rating}")
        print(f" SUCCESS RATE: {success_rate:.1f}%")
        print(f"ACCURACY SCORE: {overall_accuracy:.1f}%")
        print(f" Successful scrapes: {scraper_metrics['successful_scrapes']}/{scraper_metrics['total_tests']}")
        print(f" Report saved: {report_file}")
        
    except Exception as e:
        print(f" Evaluation failed: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()